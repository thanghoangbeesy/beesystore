// Trình soạn thảo mô tả sản phẩm (rich text) - tự dựng bằng contentEditable,
// lưu mô tả dạng HTML. Mô tả cũ dạng chữ thuần tự được chuyển thành đoạn văn.
import { useEffect, useRef, useState } from 'react';
import type { StoreSettings } from '../lib/types';
import { isHtmlText } from '../lib/sanitize';
import { isUploadConfigured, uploadImage } from '../lib/upload';
import { Icon } from './Icon';

interface Props {
  value: string;
  onChange: (html: string) => void;
  settings: StoreSettings;
}

function toInitialHtml(value: string): string {
  if (!value.trim()) return '<p><br></p>';
  if (isHtmlText(value)) return value;
  return value
    .split(/\n{2,}/)
    .map((block) => `<p>${block.split('\n').join('<br>')}</p>`)
    .join('');
}

export function RichTextEditor({ value, onChange, settings }: Props) {
  const editorRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const initDone = useRef(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => {
    if (editorRef.current && !initDone.current) {
      editorRef.current.innerHTML = toInitialHtml(value);
      initDone.current = true;
    }
    // Chỉ nạp nội dung 1 lần khi mở form
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const emit = () => {
    if (editorRef.current) onChange(editorRef.current.innerHTML);
  };

  const cmd = (command: string, arg?: string) => {
    editorRef.current?.focus();
    document.execCommand('styleWithCSS', false, 'true');
    document.execCommand(command, false, arg);
    emit();
  };

  const insertImageUrl = (url: string) => {
    editorRef.current?.focus();
    document.execCommand('insertImage', false, url);
    emit();
  };

  const handleImageButton = () => {
    setErr('');
    if (isUploadConfigured(settings)) {
      fileRef.current?.click();
    } else {
      const url = window.prompt(
        'Dán link ảnh để chèn (muốn tải ảnh từ máy: vào Cài đặt điền cấu hình Cloudinary trước):',
      );
      if (url && url.trim()) insertImageUrl(url.trim());
    }
  };

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setBusy(true);
    setErr('');
    try {
      const url = await uploadImage(file, settings);
      insertImageUrl(url);
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : 'Tải ảnh thất bại.');
    } finally {
      setBusy(false);
    }
  };

  const handleLink = () => {
    const url = window.prompt('Dán địa chỉ liên kết (https://...):');
    if (url && url.trim()) cmd('createLink', url.trim());
  };

  const btn = (
    title: string,
    onClick: () => void,
    children: React.ReactNode,
    active = false,
  ) => (
    <button
      type="button"
      title={title}
      className={`rte-btn${active ? ' active' : ''}`}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
    >
      {children}
    </button>
  );

  const inputStyle: React.CSSProperties = {
    padding: '6px 8px', border: '1px solid #e0e6ea', borderRadius: 8, fontSize: 13.5,
  };

  return (
    <div className="rte">
      <div className="rte-toolbar">
        {btn('Chữ đậm', () => cmd('bold'), <b>B</b>)}
        {btn('Chữ nghiêng', () => cmd('italic'), <i>I</i>)}
        {btn('Gạch chân', () => cmd('underline'), <u>U</u>)}
        {btn('Gạch ngang', () => cmd('strikeThrough'), <s>S</s>)}
        <span className="rte-sep" />
        <select
          style={inputStyle}
          defaultValue=""
          onChange={(e) => {
            if (e.target.value) cmd('fontName', e.target.value);
            e.target.value = '';
          }}
          title="Font chữ (chọn đoạn văn trước)"
        >
          <option value="">Font chữ</option>
          <option value="Inter">Inter (mặc định)</option>
          <option value="Georgia">Georgia (serif)</option>
          <option value="Arial">Arial</option>
          <option value="'Courier New'">Courier (mono)</option>
        </select>
        <select
          style={inputStyle}
          defaultValue=""
          onChange={(e) => {
            if (e.target.value) cmd('fontSize', e.target.value);
            e.target.value = '';
          }}
          title="Cỡ chữ (chọn đoạn văn trước)"
        >
          <option value="">Cỡ chữ</option>
          <option value="2">Nhỏ</option>
          <option value="3">Vừa</option>
          <option value="5">Lớn</option>
          <option value="6">Rất lớn</option>
        </select>
        <span className="rte-sep" />
        <label className="rte-color" title="Màu chữ">
          A
          <input
            type="color"
            onChange={(e) => cmd('foreColor', e.target.value)}
          />
        </label>
        <label className="rte-color hl" title="Màu nền chữ">
          A
          <input
            type="color"
            defaultValue="#fff3e6"
            onChange={(e) => cmd('hiliteColor', e.target.value)}
          />
        </label>
        <span className="rte-sep" />
        {btn('Tiêu đề lớn', () => cmd('formatBlock', 'H2'), 'H2')}
        {btn('Tiêu đề nhỏ', () => cmd('formatBlock', 'H3'), 'H3')}
        {btn('Đoạn văn thường', () => cmd('formatBlock', 'P'), 'P')}
        {btn('Danh sách chấm', () => cmd('insertUnorderedList'), <Icon name="list" size={15} />)}
        {btn('Danh sách số', () => cmd('insertOrderedList'), '1.')}
        <span className="rte-sep" />
        {btn('Căn trái', () => cmd('justifyLeft'), <Icon name="alignL" size={15} />)}
        {btn('Căn giữa', () => cmd('justifyCenter'), <Icon name="alignC" size={15} />)}
        {btn('Căn phải', () => cmd('justifyRight'), <Icon name="alignR" size={15} />)}
        <span className="rte-sep" />
        {btn('Chèn liên kết', handleLink, <Icon name="link" size={15} />)}
        {btn('Chèn ảnh', handleImageButton, <Icon name="image" size={15} />)}
        {btn('Xóa định dạng', () => cmd('removeFormat'), <Icon name="eraser" size={15} />)}
      </div>
      <div
        ref={editorRef}
        className="rte-body"
        contentEditable
        suppressContentEditableWarning
        onInput={emit}
        onBlur={emit}
      />
      <input ref={fileRef} type="file" accept="image/*" hidden onChange={handleFile} />
      {busy && <p className="f-hint">Đang tải ảnh lên...</p>}
      {err && <p className="f-err">{err}</p>}
      <p className="f-hint">
        Mẹo: bôi đen đoạn chữ rồi mới bấm nút định dạng/cỡ chữ/màu. Bấm nút ảnh để chèn ảnh vào mô tả.
      </p>
    </div>
  );
}
