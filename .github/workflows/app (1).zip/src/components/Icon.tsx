// Bộ icon lineal (SVG outline, nét mảnh) dùng chung toàn web.
// Không dùng emoji làm icon.
import type { SVGProps } from 'react';

export type IconName =
  | 'search' | 'bag' | 'phone' | 'chat' | 'home' | 'grid' | 'tag' | 'shield'
  | 'box' | 'doc' | 'check' | 'x' | 'menu' | 'chevD' | 'chevR' | 'chevL'
  | 'clock' | 'download' | 'settings' | 'logout' | 'plus' | 'edit' | 'trash'
  | 'eye' | 'copy' | 'bolt' | 'wallet' | 'lock' | 'bulb' | 'lifebuoy'
  | 'star' | 'receipt' | 'qr' | 'user' | 'mail' | 'image' | 'alert'
  | 'ticket' | 'cart' | 'store' | 'truck' | 'refresh' | 'link' | 'send'
  | 'sheet' | 'web' | 'app' | 'facebook' | 'youtube' | 'globe'
  | 'list' | 'alignL' | 'alignC' | 'alignR' | 'eraser';

const paths: Record<IconName, React.ReactNode> = {
  search: <circle cx="11" cy="11" r="7" />,
  bag: <path d="M6 8h12l1 12H5L6 8z" />,
  phone: <path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z" />,
  chat: <path d="M21 12a8 8 0 0 1-8 8H4l2-3a8 8 0 1 1 15-5z" />,
  home: <path d="M3 11l9-8 9 8" />,
  grid: <path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z" />,
  tag: <path d="M3 3h7l11 11-7 7L3 10V3z" />,
  shield: <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z" />,
  box: <path d="M3 8l9-5 9 5v8l-9 5-9-5V8z" />,
  doc: <path d="M6 3h8l4 4v14H6V3z" />,
  check: <path d="M4 12.5l5 5L20 6.5" />,
  x: <path d="M6 6l12 12M18 6L6 18" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  chevD: <path d="M6 9l6 6 6-6" />,
  chevR: <path d="M9 6l6 6-6 6" />,
  chevL: <path d="M15 6l-6 6 6 6" />,
  clock: <circle cx="12" cy="12" r="8" />,
  download: <path d="M12 4v11m0 0l-4-4m4 4l4-4" />,
  settings: <circle cx="12" cy="12" r="3" />,
  logout: <path d="M9 4H4v16h5M15 8l4 4-4 4M19 12H9" />,
  plus: <path d="M12 5v14M5 12h14" />,
  edit: <path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19l-4 1z" />,
  trash: <path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" />,
  eye: <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z" />,
  copy: <path d="M9 9h11v11H9zM5 15H4V4h11v1" />,
  bolt: <path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" />,
  wallet: <path d="M3 7a2 2 0 0 1 2-2h14v12H5a2 2 0 0 1-2-2V7z" />,
  lock: <path d="M6 11V8a6 6 0 0 1 12 0v3" />,
  bulb: <path d="M9 18h6M10 21h4" />,
  lifebuoy: <circle cx="12" cy="12" r="9" />,
  star: <path d="M12 3l2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-3-5.4 3 1.1-6L3.2 9.4l6.1-.8L12 3z" />,
  receipt: <path d="M6 3h12v18l-2-1.5L14 21l-2-1.5L10 21l-2-1.5L6 21V3z" />,
  qr: <path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4z" />,
  user: <circle cx="12" cy="8" r="4" />,
  mail: <path d="M3 6h18v12H3z" />,
  image: <path d="M4 4h16v16H4z" />,
  alert: <path d="M12 3l10 17H2L12 3z" />,
  ticket: <path d="M4 8a2 2 0 0 0 2-2h12a2 2 0 0 0 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 0-2 2H6a2 2 0 0 0-2-2v-2a2 2 0 0 0 0-4V8z" />,
  cart: <path d="M3 4h2l2.5 11h11L21 8H7" />,
  store: <path d="M4 9l1-4h14l1 4M4 9v11h16V9M4 9h16M9 20v-6h6v6" />,
  truck: <path d="M2 6h12v10H2zM14 10h4l4 4v2h-8" />,
  refresh: <path d="M20 12a8 8 0 1 1-2.3-5.6M20 4v4h-4" />,
  link: <path d="M10 14a4 4 0 0 0 6 0l3-3a4 4 0 0 0-6-6l-1.5 1.5M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 0 0 6 6l1.5-1.5" />,
  send: <path d="M21 3L10 14M21 3l-7 18-4-7-7-4 18-7z" />,
  list: (
    <>
      <path d="M9.5 6H20M9.5 12H20M9.5 18H20" />
      <circle cx="4.5" cy="6" r="1.2" />
      <circle cx="4.5" cy="12" r="1.2" />
      <circle cx="4.5" cy="18" r="1.2" />
    </>
  ),
  alignL: <path d="M4 6h16M4 10h9M4 14h16M4 18h9" />,
  alignC: <path d="M4 6h16M7.5 10h9M4 14h16M7.5 18h9" />,
  alignR: <path d="M4 6h16M11 10h9M4 14h16M11 18h9" />,
  eraser: <path d="M7 21l-4.5-4.5L13 6l5 5-7.5 7.5H7zM11 21h9" />,
  sheet: <path d="M6 3h8l4 4v14H6V3z" />,
  web: <circle cx="12" cy="12" r="9" />,
  app: <path d="M7 3h10a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" />,
  facebook: <path d="M14 8h2V4h-3a4 4 0 0 0-4 4v3H7v4h2v6h4v-6h2.5l.5-4H13V8.5A.5.5 0 0 1 14 8z" />,
  youtube: <path d="M3 8a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8z" />,
  globe: <circle cx="12" cy="12" r="9" />,
};

// Extra inner details per icon (rendered after the base path)
const extras: Partial<Record<IconName, React.ReactNode>> = {
  search: <path d="M16 16l5 5" />,
  home: <path d="M5 10v10h14V10" />,
  user: <path d="M4 20a8 8 0 0 1 16 0" />,
  mail: <path d="M3 7l9 6 9-6" />,
  image: <><circle cx="9" cy="9" r="1.6" /><path d="M4 18l5-5 3 3 4-4 4 4" /></>,
  clock: <path d="M12 7v5l3 2" />,
  download: <path d="M4 19h16" />,
  settings: <path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" />,
  lock: <path d="M5 11h14v10H5z" />,
  wallet: <><path d="M19 9h1a1 1 0 0 1 1 1v8a2 2 0 0 1-2 2H5" /><circle cx="16.5" cy="14" r="1.2" /></>,
  bulb: <path d="M12 3a6 6 0 0 0-4 10.5c.8.7 1 1.5 1 2.5h6c0-1 .2-1.8 1-2.5A6 6 0 0 0 12 3z" />,
  lifebuoy: <><circle cx="12" cy="12" r="4" /><path d="M5.6 5.6l3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9" /></>,
  receipt: <path d="M9 8h6M9 12h6" />,
  qr: <><path d="M14 14h3v3h-3zM20 14v6h-6" /><path d="M7 7h0" /></>,
  alert: <path d="M12 9v5M12 17.5h0" />,
  ticket: <path d="M14 6v2M14 11v2M14 16v2" />,
  cart: <><circle cx="9" cy="19" r="1.4" /><circle cx="17" cy="19" r="1.4" /></>,
  web: <path d="M3 12h18M12 3c3 3.5 3 14 0 18M12 3c-3 3.5-3 14 0 18" />,
  app: <path d="M11 18h2" />,
  sheet: <path d="M9 12h6M9 15.5h6M9 8.5h3" />,
  doc: <path d="M14 3v4h4M9 12h6M9 15.5h6" />,
  box: <path d="M3 8l9 5 9-5M12 13v8" />,
  youtube: <path d="M10.5 9.8v4.4L14.5 12l-4-2.2z" />,
  globe: <path d="M3 12h18M12 3c3 3.5 3 14 0 18M12 3c-3 3.5-3 14 0 18" />,
  edit: <path d="M14.5 6.5l3 3" />,
  eye: <circle cx="12" cy="12" r="2.4" />,
  send: <path d="M10 14l4-4" />,
  refresh: <path d="M4 4v4h4" />,
  store: <path d="M9 13h6" />,
};

export function Icon({
  name,
  size = 20,
  strokeWidth = 1.7,
  className,
  style,
}: {
  name: IconName;
  size?: number;
  strokeWidth?: number;
  className?: string;
  style?: React.CSSProperties;
} & Omit<SVGProps<SVGSVGElement>, 'width' | 'height'>) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={style}
      aria-hidden="true"
    >
      {paths[name]}
      {extras[name]}
    </svg>
  );
}
