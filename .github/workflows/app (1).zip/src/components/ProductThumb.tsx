// Ảnh đại diện placeholder: gradient + icon lineal theo loại sản phẩm.
// TODO: Hoàng thay bằng ảnh chụp thật của từng app (trường product.thumbnail).
import { Icon, type IconName } from './Icon';

const styleByType: Record<string, { bg: string; icon: IconName }> = {
  Webapp: { bg: 'linear-gradient(135deg,#00b14f,#0b6e38)', icon: 'app' },
  'Google Sheet': { bg: 'linear-gradient(135deg,#0f9d58,#0b6e38)', icon: 'sheet' },
  Website: { bg: 'linear-gradient(135deg,#ff7a00,#e56c00)', icon: 'web' },
  Template: { bg: 'linear-gradient(135deg,#7a5cff,#4a2fb3)', icon: 'doc' },
};

export function ProductThumb({
  type,
  thumbnail,
  size = 64,
}: {
  type: string;
  thumbnail?: string;
  size?: number;
}) {
  if (thumbnail) return <img src={thumbnail} alt="" loading="lazy" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />;
  const s = styleByType[type] || styleByType['Webapp'];
  return (
    <div className="ph" style={{ background: s.bg }}>
      <Icon name={s.icon} size={size} strokeWidth={1.4} />
    </div>
  );
}
