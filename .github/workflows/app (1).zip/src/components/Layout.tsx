import { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useStore } from '../lib/store';
import { isDemoMode } from '../lib/db';
import { Icon } from './Icon';

function PromoBanner() {
  const { settings } = useStore();
  if (!settings.bannerActive || !settings.bannerText) return null;
  return (
    <div className="promo-banner">
      <Icon name="ticket" size={17} className="icon" />
      <span>{settings.bannerText}</span>
    </div>
  );
}

function Header() {
  const { settings } = useStore();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const navigate = useNavigate();

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setOpen(false);
    navigate(q.trim() ? `/?q=${encodeURIComponent(q.trim())}` : '/');
  };

  return (
    <header className="site-header">
      <div className="header-pill">
        <Link to="/" className="logo" onClick={() => setOpen(false)}>
          <span className="logo-mark">B</span>
          <span>
            <b>Beesy</b> <span>Store</span>
          </span>
        </Link>
        <nav className="nav-desktop">
          <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
            Trang chủ
          </NavLink>
          <NavLink to="/tra-cuu" className={({ isActive }) => (isActive ? 'active' : '')}>
            Tra cứu đơn
          </NavLink>
        </nav>
        <form className="header-search" onSubmit={submitSearch}>
          <Icon name="search" size={17} className="icon" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Tìm webapp, template..."
          />
        </form>
        <div className="header-actions">
          <a
            className="btn btn-green"
            href={`https://zalo.me/${settings.zalo.replace(/\s/g, '')}`}
            target="_blank"
            rel="noreferrer"
          >
            <Icon name="chat" size={17} />
            <span className="hide-sm">Chat Zalo</span>
          </a>
          <button
            className="icon-btn mobile-menu-btn"
            onClick={() => setOpen((o) => !o)}
            aria-label="Menu"
          >
            <Icon name={open ? 'x' : 'menu'} size={20} />
          </button>
        </div>
      </div>
      <nav className={`mobile-nav${open ? ' open' : ''}`}>
        <form className="m-search" onSubmit={submitSearch}>
          <Icon name="search" size={17} className="icon" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Tìm webapp, template..."
          />
        </form>
        <NavLink to="/" end onClick={() => setOpen(false)} className={({ isActive }) => (isActive ? 'active' : '')}>
          <Icon name="home" size={18} /> Trang chủ
        </NavLink>
        <NavLink to="/tra-cuu" onClick={() => setOpen(false)} className={({ isActive }) => (isActive ? 'active' : '')}>
          <Icon name="receipt" size={18} /> Tra cứu đơn hàng
        </NavLink>
      </nav>
    </header>
  );
}

function Footer() {
  const { settings } = useStore();
  const zaloNum = settings.zalo.replace(/\s/g, '');
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <div className="f-brand">
              <span className="logo-mark">B</span>
              <span>Beesy Store</span>
            </div>
            <p className="desc">
              Kho webapp, Google Sheet và website làm sẵn - mua một lần, dùng vĩnh viễn,
              hỗ trợ tận tay bởi chính người làm ra sản phẩm.
            </p>
            <div className="f-contact">
              <a href={`tel:${settings.hotline.replace(/\s/g, '')}`}>
                <Icon name="phone" size={17} /> {settings.hotline}
              </a>
              <a href={`https://zalo.me/${zaloNum}`} target="_blank" rel="noreferrer">
                <Icon name="chat" size={17} /> Zalo: {settings.zalo}
              </a>
            </div>
          </div>
          <div>
            <h4>Kết nối</h4>
            <ul className="f-links">
              <li>
                <a href={`https://zalo.me/${zaloNum}`} target="_blank" rel="noreferrer">
                  Nhắn Zalo shop
                </a>
              </li>
              <li>
                <a href={`tel:${settings.hotline.replace(/\s/g, '')}`}>Gọi hotline</a>
              </li>
              <li>
                <Link to="/tra-cuu">Tra cứu đơn hàng</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>Cộng đồng</h4>
            <ul className="f-links">
              <li>
                <Link to="/">Tất cả sản phẩm</Link>
              </li>
              <li>
                <a href={`https://zalo.me/${zaloNum}`} target="_blank" rel="noreferrer">
                  Nhóm Zalo hỗ trợ
                </a>
              </li>
              <li>
                <Link to="/tra-cuu">Chính sách mua hàng</Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>(c) {new Date().getFullYear()} {settings.shopName}. Mua một lần, dùng vĩnh viễn.</span>
          <span>Liên hệ: {settings.hotline}</span>
        </div>
      </div>
    </footer>
  );
}

export function Layout() {
  const { settings } = useStore();
  const zaloNum = settings.zalo.replace(/\s/g, '');
  return (
    <>
      <PromoBanner />
      <Header />
      <main>
        <Outlet />
      </main>
      <Footer />
      <a
        className="zalo-float"
        href={`https://zalo.me/${zaloNum}`}
        target="_blank"
        rel="noreferrer"
        aria-label="Chat Zalo"
      >
        Zalo
      </a>
      {isDemoMode && <div className="demo-badge">Bản demo - chưa kết nối Firebase</div>}
    </>
  );
}
