// Trang quản lý Đơn hàng: lọc theo trạng thái, xem chi tiết, xác nhận/hủy
import { useEffect, useState } from 'react';
import { listOrders, setOrderStatus } from '../../lib/db';
import type { Order, OrderStatus } from '../../lib/types';
import { fmtVND, timeAgo } from '../../lib/format';
import { Icon } from '../../components/Icon';

const STATUS_LABEL: Record<OrderStatus, string> = {
  pending: 'Chờ thanh toán',
  paid: 'Đã thanh toán',
  confirmed: 'Đã xác nhận',
  cancelled: 'Đã hủy',
};

type Filter = OrderStatus | 'all';

const FILTERS: { key: Filter; label: string }[] = [
  { key: 'all', label: 'Tất cả' },
  { key: 'pending', label: 'Chờ thanh toán' },
  { key: 'paid', label: 'Đã thanh toán' },
  { key: 'confirmed', label: 'Đã xác nhận' },
  { key: 'cancelled', label: 'Đã hủy' },
];

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [filter, setFilter] = useState<Filter>('all');
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [selected, setSelected] = useState<Order | null>(null);
  const [acting, setActing] = useState(false);
  const [actErr, setActErr] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await listOrders('all');
        if (alive) setOrders(data);
      } catch {
        if (alive) setErr('Không tải được danh sách đơn hàng.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const visible = filter === 'all' ? orders : orders.filter((o) => o.status === filter);

  function countOf(f: Filter): number {
    if (f === 'all') return orders.length;
    return orders.filter((o) => o.status === f).length;
  }

  function updateLocal(updated: Order) {
    setOrders((list) => list.map((o) => (o.code === updated.code ? updated : o)));
    setSelected((s) => (s && s.code === updated.code ? updated : s));
  }

  async function confirmOrder(order: Order) {
    setActing(true);
    setActErr('');
    try {
      await setOrderStatus(order.code, 'confirmed');
      updateLocal({ ...order, status: 'confirmed', confirmedAt: Date.now() });
    } catch {
      setActErr('Xác nhận đơn thất bại. Vui lòng thử lại.');
    } finally {
      setActing(false);
    }
  }

  async function cancelOrder(order: Order) {
    if (!window.confirm(`Hủy đơn ${order.code}? Thao tác này không thể hoàn tác.`)) return;
    setActing(true);
    setActErr('');
    try {
      await setOrderStatus(order.code, 'cancelled');
      updateLocal({ ...order, status: 'cancelled' });
    } catch {
      setActErr('Hủy đơn thất bại. Vui lòng thử lại.');
    } finally {
      setActing(false);
    }
  }

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
        {FILTERS.map((f) => (
          <button
            key={f.key}
            className={'mini-btn' + (filter === f.key ? ' green' : '')}
            onClick={() => setFilter(f.key)}
          >
            {f.label} ({countOf(f.key)})
          </button>
        ))}
      </div>

      {err && <p className="f-err">{err}</p>}
      {loading ? (
        <p>Đang tải...</p>
      ) : visible.length === 0 ? (
        <p className="empty">Không có đơn hàng nào trong mục này.</p>
      ) : (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Khách hàng</th>
                <th>Tổng</th>
                <th>Trạng thái</th>
                <th>Thời gian</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {visible.map((o) => (
                <tr key={o.id}>
                  <td><b style={{ fontFamily: 'monospace' }}>{o.code}</b></td>
                  <td>
                    <b>{o.customerName}</b>
                    <div style={{ fontSize: 12.5, color: '#6b7684' }}>{o.customerPhone}</div>
                  </td>
                  <td>{fmtVND(o.total)}</td>
                  <td>
                    <span className={'status-pill ' + o.status}>{STATUS_LABEL[o.status]}</span>
                  </td>
                  <td>{timeAgo(o.createdAt)}</td>
                  <td>
                    <button className="mini-btn" onClick={() => { setSelected(o); setActErr(''); }}>
                      <Icon name="eye" size={16} /> Chi tiết
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 560 }}>
            <div className="modal-head">
              <h3>Đơn {selected.code}</h3>
              <button className="icon-btn" onClick={() => setSelected(null)} aria-label="Đóng">
                <Icon name="x" size={20} />
              </button>
            </div>
            <div className="modal-body">
              <div className="panel" style={{ marginBottom: 14 }}>
                <h3 style={{ fontSize: 14.5 }}>Thông tin khách hàng</h3>
                <p><b>{selected.customerName}</b></p>
                <p>SĐT: {selected.customerPhone}</p>
                {selected.customerEmail && <p>Email: {selected.customerEmail}</p>}
                {selected.note && <p>Ghi chú: {selected.note}</p>}
              </div>

              <div className="panel" style={{ marginBottom: 14 }}>
                <h3 style={{ fontSize: 14.5 }}>Sản phẩm</h3>
                {selected.items.map((it, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', gap: 10, padding: '7px 0' }}>
                    <span>
                      <b>{it.productName}</b> <span style={{ color: '#6b7684' }}>{it.version}</span>
                      <span style={{ color: '#6b7684' }}> × {it.qty}</span>
                    </span>
                    <span>{fmtVND(it.price * it.qty)}</span>
                  </div>
                ))}
                <div className="order-line">
                  <span>Tạm tính</span>
                  <span>{fmtVND(selected.subtotal)}</span>
                </div>
                {selected.discount > 0 && (
                  <div className="order-line">
                    <span>Giảm giá{selected.voucherCode ? ` (${selected.voucherCode})` : ''}</span>
                    <span className="disc">-{fmtVND(selected.discount)}</span>
                  </div>
                )}
                <div className="order-line total">
                  <span>Tổng cộng</span>
                  <b>{fmtVND(selected.total)}</b>
                </div>
              </div>

              <div className="panel" style={{ marginBottom: 14 }}>
                <h3 style={{ fontSize: 14.5 }}>Trạng thái</h3>
                <p>Đã tạo: {timeAgo(selected.createdAt)}</p>
                {selected.paidAt && <p>Đã thanh toán: {timeAgo(selected.paidAt)}</p>}
                {selected.confirmedAt && <p>Đã xác nhận: {timeAgo(selected.confirmedAt)}</p>}
                <p style={{ marginTop: 8 }}>
                  <span className={'status-pill ' + selected.status}>{STATUS_LABEL[selected.status]}</span>
                </p>
              </div>

              {actErr && <p className="f-err">{actErr}</p>}

              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {selected.status === 'paid' && (
                  <button className="btn btn-green" disabled={acting} onClick={() => confirmOrder(selected)}>
                    <Icon name="check" size={18} /> Xác nhận thanh toán
                  </button>
                )}
                {(selected.status === 'pending' || selected.status === 'paid') && (
                  <button className="btn btn-danger" disabled={acting} onClick={() => cancelOrder(selected)}>
                    <Icon name="x" size={18} /> Hủy đơn
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
