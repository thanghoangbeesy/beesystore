// Trang Tổng quan: doanh thu, thống kê, đơn hàng mới nhất
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getRevenueStats } from '../../lib/db';
import type { OrderStatus } from '../../lib/types';
import { fmtVND, timeAgo } from '../../lib/format';

const STATUS_LABEL: Record<OrderStatus, string> = {
  pending: 'Chờ thanh toán',
  paid: 'Đã thanh toán',
  confirmed: 'Đã xác nhận',
  cancelled: 'Đã hủy',
};

export default function Dashboard() {
  const [stats, setStats] = useState<Awaited<ReturnType<typeof getRevenueStats>> | null>(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    let alive = true;
    getRevenueStats()
      .then((s) => alive && setStats(s))
      .catch(() => alive && setErr('Không tải được dữ liệu thống kê.'));
    return () => {
      alive = false;
    };
  }, []);

  if (err) return <p className="f-err">{err}</p>;
  if (!stats) return <p>Đang tải...</p>;

  const total = stats.byStatus.pending + stats.byStatus.paid + stats.byStatus.confirmed + stats.byStatus.cancelled;
  const maxRevenue = Math.max(0, ...stats.last7.map((d) => d.revenue));

  return (
    <div>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="k">Doanh thu (đơn đã xác nhận)</div>
          <div className="v green">{fmtVND(stats.revenue)}</div>
        </div>
        <div className="stat-card">
          <div className="k">Chờ thanh toán</div>
          <div className="v">{stats.byStatus.pending}</div>
        </div>
        <div className="stat-card">
          <div className="k">Chờ xác nhận</div>
          <div className="v orange">{stats.byStatus.paid}</div>
        </div>
        <div className="stat-card">
          <div className="k">Tổng đơn</div>
          <div className="v">{total}</div>
        </div>
      </div>

      <div className="panel">
        <h3>Doanh thu 7 ngày qua</h3>
        <div className="chart">
          {stats.last7.map((d) => {
            const pct = maxRevenue > 0 && d.revenue > 0 ? (d.revenue / maxRevenue) * 100 : 0;
            return (
              <div className="bar-col" key={d.label}>
                <div
                  className={'bar' + (d.revenue === 0 ? ' zero' : '')}
                  style={{ height: `${pct}%` }}
                  title={`${d.label}: ${fmtVND(d.revenue)} (${d.count} đơn)`}
                />
                <span className="bl">{d.label}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="panel">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <h3 style={{ marginBottom: 0 }}>Đơn hàng mới nhất</h3>
          <Link to="/admin/don-hang" style={{ fontSize: 13.5, fontWeight: 700 }}>
            Xem tất cả
          </Link>
        </div>
        {stats.recent.length === 0 ? (
          <p className="empty">Chưa có đơn hàng nào.</p>
        ) : (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Mã đơn</th>
                  <th>Khách hàng</th>
                  <th>Tổng</th>
                  <th>Trạng thái</th>
                  <th>Thời gian</th>
                </tr>
              </thead>
              <tbody>
                {stats.recent.map((o) => (
                  <tr key={o.id}>
                    <td><b style={{ fontFamily: 'monospace' }}>{o.code}</b></td>
                    <td>{o.customerName}</td>
                    <td>{fmtVND(o.total)}</td>
                    <td>
                      <span className={'status-pill ' + o.status}>{STATUS_LABEL[o.status]}</span>
                    </td>
                    <td>{timeAgo(o.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
