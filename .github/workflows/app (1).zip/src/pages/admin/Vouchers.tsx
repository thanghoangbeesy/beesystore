// Trang quản lý Voucher (tạo/sửa/xóa mã giảm giá)
import { useEffect, useState } from 'react';
import { deleteVoucher, getAllVouchers, saveVoucher } from '../../lib/db';
import type { Voucher } from '../../lib/types';
import { fmtVND } from '../../lib/format';
import { Icon } from '../../components/Icon';

interface FormState {
  code: string;
  type: 'percent' | 'fixed';
  value: string;
  maxDiscount: string;
  minOrder: string;
  usageLimit: string;
  expiresAt: string; // yyyy-mm-dd
  active: boolean;
}

function blankForm(): FormState {
  return {
    code: '',
    type: 'percent',
    value: '10',
    maxDiscount: '',
    minOrder: '',
    usageLimit: '',
    expiresAt: '',
    active: true,
  };
}

function toForm(v: Voucher): FormState {
  return {
    code: v.code,
    type: v.type,
    value: String(v.value),
    maxDiscount: v.maxDiscount != null ? String(v.maxDiscount) : '',
    minOrder: v.minOrder != null ? String(v.minOrder) : '',
    usageLimit: v.usageLimit != null ? String(v.usageLimit) : '',
    expiresAt: v.expiresAt ? new Date(v.expiresAt).toISOString().slice(0, 10) : '',
    active: v.active,
  };
}

function inputStyle(): React.CSSProperties {
  return { width: '100%', padding: '10px 12px', border: '1px solid #e0e6ea', borderRadius: 10 };
}

function fmtExpiry(ts?: number): string {
  if (!ts) return '-';
  return new Date(ts).toLocaleDateString('vi-VN');
}

export default function Vouchers() {
  const [list, setList] = useState<Voucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Voucher | null>(null);
  const [form, setForm] = useState<FormState>(blankForm);
  const [formErr, setFormErr] = useState('');
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    setErr('');
    try {
      setList(await getAllVouchers());
    } catch {
      setErr('Không tải được danh sách voucher.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await getAllVouchers();
        if (alive) setList(data);
      } catch {
        if (alive) setErr('Không tải được danh sách voucher.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function openCreate() {
    setEditing(null);
    setForm(blankForm());
    setFormErr('');
    setShowModal(true);
  }

  function openEdit(v: Voucher) {
    setEditing(v);
    setForm(toForm(v));
    setFormErr('');
    setShowModal(true);
  }

  async function handleDelete(id: string, code: string) {
    if (!window.confirm(`Xóa voucher "${code}"? Thao tác này không thể hoàn tác.`)) return;
    try {
      await deleteVoucher(id);
      setList((l) => l.filter((v) => v.id !== id));
    } catch {
      alert('Xóa voucher thất bại. Vui lòng thử lại.');
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setFormErr('');
    const code = form.code.trim().toUpperCase();
    if (!code) {
      setFormErr('Vui lòng nhập mã voucher.');
      return;
    }
    const value = Number(form.value);
    if (!Number.isFinite(value) || value <= 0) {
      setFormErr('Giá trị voucher không hợp lệ.');
      return;
    }
    if (form.type === 'percent' && value > 100) {
      setFormErr('Phần trăm giảm không được vượt quá 100.');
      return;
    }
    const maxDiscount = form.maxDiscount.trim() === '' ? undefined : Number(form.maxDiscount);
    const minOrder = form.minOrder.trim() === '' ? undefined : Number(form.minOrder);
    const usageLimit = form.usageLimit.trim() === '' ? undefined : Number(form.usageLimit);
    for (const [label, n] of [['Trần giảm giá', maxDiscount], ['Đơn tối thiểu', minOrder], ['Giới hạn lượt dùng', usageLimit]] as const) {
      if (n !== undefined && (!Number.isFinite(n) || n < 0)) {
        setFormErr(`${label} không hợp lệ.`);
        return;
      }
    }
    let expiresAt: number | undefined;
    if (form.expiresAt) {
      const d = new Date(form.expiresAt + 'T23:59:59.999');
      if (Number.isNaN(d.getTime())) {
        setFormErr('Ngày hết hạn không hợp lệ.');
        return;
      }
      expiresAt = d.getTime();
    }

    setSaving(true);
    try {
      const v: Voucher = {
        id: editing?.id ?? '',
        code,
        type: form.type,
        value,
        maxDiscount,
        minOrder,
        usageLimit: usageLimit != null ? Math.floor(usageLimit) : undefined,
        usedCount: editing?.usedCount ?? 0,
        active: form.active,
        expiresAt,
      };
      await saveVoucher(v);
      setShowModal(false);
      await load();
    } catch {
      setFormErr('Lưu voucher thất bại. Vui lòng thử lại.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div style={{ marginBottom: 16 }}>
        <button className="btn btn-green" onClick={openCreate}>
          <Icon name="plus" size={18} /> Tạo voucher
        </button>
      </div>

      {err && <p className="f-err">{err}</p>}
      {loading ? (
        <p>Đang tải...</p>
      ) : list.length === 0 ? (
        <p className="empty">Chưa có voucher nào. Nhấn "Tạo voucher" để tạo mới.</p>
      ) : (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>Mã</th>
                <th>Loại</th>
                <th>Giá trị</th>
                <th>Đã dùng</th>
                <th>Hết hạn</th>
                <th>Trạng thái</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((v) => (
                <tr key={v.id}>
                  <td><b style={{ textTransform: 'uppercase' }}>{v.code}</b></td>
                  <td>{v.type === 'percent' ? '%' : 'đ'}</td>
                  <td>
                    {v.type === 'percent' ? `${v.value}%` : fmtVND(v.value)}
                    {v.type === 'percent' && v.maxDiscount != null && (
                      <div style={{ fontSize: 12.5, color: '#6b7684' }}>
                        Tối đa {fmtVND(v.maxDiscount)}
                      </div>
                    )}
                  </td>
                  <td>{v.usedCount}/{v.usageLimit != null ? v.usageLimit : 'khong gioi han'}</td>
                  <td>{fmtExpiry(v.expiresAt)}</td>
                  <td>
                    <span className={'status-pill ' + (v.active ? 'confirmed' : 'cancelled')}>
                      {v.active ? 'Đang chạy' : 'Đã tắt'}
                    </span>
                  </td>
                  <td>
                    <div className="row-actions">
                      <button className="mini-btn" onClick={() => openEdit(v)} title="Sửa">
                        <Icon name="edit" size={16} /> Sửa
                      </button>
                      <button className="mini-btn red" onClick={() => handleDelete(v.id, v.code)} title="Xóa">
                        <Icon name="trash" size={16} /> Xóa
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 520 }}>
            <div className="modal-head">
              <h3>{editing ? 'Sửa voucher' : 'Tạo voucher'}</h3>
              <button className="icon-btn" onClick={() => setShowModal(false)} aria-label="Đóng">
                <Icon name="x" size={20} />
              </button>
            </div>
            <div className="modal-body">
              <form onSubmit={handleSave} className="form-grid">
                <div>
                  <label className="f-label">Mã voucher *</label>
                  <input
                    value={form.code}
                    onChange={(e) => set('code', e.target.value)}
                    style={{ ...inputStyle(), textTransform: 'uppercase' }}
                    placeholder="VD: BEESY40"
                  />
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <div>
                    <label className="f-label">Loại giảm</label>
                    <select value={form.type} onChange={(e) => set('type', e.target.value as FormState['type'])} style={inputStyle()}>
                      <option value="percent">Phần trăm (%)</option>
                      <option value="fixed">Số tiền (đ)</option>
                    </select>
                  </div>
                  <div>
                    <label className="f-label">Giá trị *</label>
                    <input type="number" min={0} value={form.value} onChange={(e) => set('value', e.target.value)} style={inputStyle()} />
                  </div>
                </div>
                {form.type === 'percent' && (
                  <div>
                    <label className="f-label">Trần giảm giá (đ)</label>
                    <input type="number" min={0} value={form.maxDiscount} onChange={(e) => set('maxDiscount', e.target.value)} style={inputStyle()} placeholder="Để trống nếu không giới hạn" />
                  </div>
                )}
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <div>
                    <label className="f-label">Đơn tối thiểu (đ)</label>
                    <input type="number" min={0} value={form.minOrder} onChange={(e) => set('minOrder', e.target.value)} style={inputStyle()} placeholder="Để trống nếu không giới hạn" />
                  </div>
                  <div>
                    <label className="f-label">Giới hạn lượt dùng</label>
                    <input type="number" min={0} value={form.usageLimit} onChange={(e) => set('usageLimit', e.target.value)} style={inputStyle()} placeholder="Để trống nếu không giới hạn" />
                  </div>
                </div>
                <div>
                  <label className="f-label">Ngày hết hạn</label>
                  <input type="date" value={form.expiresAt} onChange={(e) => set('expiresAt', e.target.value)} style={inputStyle()} />
                  <p className="f-hint">Để trống nếu không hết hạn. Hiệu lực đến hết ngày đã chọn.</p>
                </div>
                <label className="check-row">
                  <input type="checkbox" checked={form.active} onChange={(e) => set('active', e.target.checked)} />
                  Đang chạy (cho phép sử dụng)
                </label>
                {formErr && <p className="f-err">{formErr}</p>}
                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                  <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>
                    Hủy
                  </button>
                  <button type="submit" className="btn btn-green" disabled={saving}>
                    {saving ? 'Đang lưu...' : 'Lưu voucher'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
