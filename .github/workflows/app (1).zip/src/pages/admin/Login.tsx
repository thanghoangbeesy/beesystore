// Trang đăng nhập trang quản trị Beesy Store
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { auth as getAuth, isConfigured } from '../../lib/firebase';
import { getSettings } from '../../lib/db';
import { Icon } from '../../components/Icon';

const DEMO_KEY = 'beesystore_demo_admin';

function friendlyError(err: unknown): string {
  const code = typeof err === 'object' && err !== null && 'code' in err ? String((err as { code: string }).code) : '';
  switch (code) {
    case 'auth/invalid-email':
      return 'Địa chỉ email không hợp lệ.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
      return 'Sai email hoặc mật khẩu. Vui lòng thử lại.';
    case 'auth/user-not-found':
      return 'Tài khoản này chưa được đăng ký.';
    case 'auth/too-many-requests':
      return 'Bạn đã thử quá nhiều lần. Vui lòng chờ một lúc rồi thử lại.';
    case 'auth/network-request-failed':
      return 'Không có kết nối mạng. Vui lòng kiểm tra lại.';
    default:
      return 'Đăng nhập thất bại. Vui lòng thử lại.';
  }
}

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const demo = !isConfigured();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    const em = email.trim();
    if (!em || !password) {
      setErr('Vui lòng nhập đầy đủ email và mật khẩu.');
      return;
    }
    setBusy(true);
    try {
      if (demo) {
        // Chế độ demo: chấp nhận bất kỳ email/password nào
        localStorage.setItem(DEMO_KEY, em);
        window.location.href = '/admin';
        return;
      }
      const cred = await signInWithEmailAndPassword(getAuth(), em, password);
      const settings = await getSettings();
      if (!settings.adminUids.includes(cred.user.uid)) {
        await signOut(getAuth());
        setErr('Tài khoản này không có quyền quản trị.');
        return;
      }
      navigate('/admin');
    } catch (e2) {
      setErr(friendlyError(e2));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={handleSubmit}>
        <div style={{ textAlign: 'center' }}>
          <Icon name="shield" size={40} />
        </div>
        <h1>Beesy Store</h1>
        <p className="sub">Đăng nhập trang quản trị</p>
        <div style={{ marginBottom: 14 }}>
          <label className="f-label" htmlFor="admin-email">
            Email
          </label>
          <input
            id="admin-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="admin@beesy.vn"
            autoComplete="username"
            style={{ width: '100%', padding: '10px 12px', border: '1px solid #e0e6ea', borderRadius: 10 }}
          />
        </div>
        <div style={{ marginBottom: 18 }}>
          <label className="f-label" htmlFor="admin-pass">
            Mật khẩu
          </label>
          <input
            id="admin-pass"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="--------"
            autoComplete="current-password"
            style={{ width: '100%', padding: '10px 12px', border: '1px solid #e0e6ea', borderRadius: 10 }}
          />
        </div>
        {err && <p className="f-err" style={{ marginBottom: 14 }}>{err}</p>}
        <button type="submit" className="btn btn-green btn-block" disabled={busy}>
          {busy ? 'Đang đăng nhập...' : 'Đăng nhập'}
        </button>
        {demo && (
          <p className="f-hint" style={{ textAlign: 'center', marginTop: 12 }}>
            Chế độ demo - đăng nhập bằng bất kỳ email nào.
          </p>
        )}
      </form>
    </div>
  );
}
