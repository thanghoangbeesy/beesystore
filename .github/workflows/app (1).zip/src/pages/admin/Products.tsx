// Trang quản lý Sản phẩm (CRUD sản phẩm số)
import { useEffect, useRef, useState } from 'react';
import { deleteProduct, getAllProducts, saveProduct } from '../../lib/db';
import type { Product, ProductVersion } from '../../lib/types';
import { fmtVND, getVersions, unsignVietnamese } from '../../lib/format';
import { isUploadConfigured, uploadImage } from '../../lib/upload';
import { useStore } from '../../lib/store';
import { Icon } from '../../components/Icon';
import { RichTextEditor } from '../../components/RichTextEditor';

const PRODUCT_TYPES = ['Webapp', 'Google Sheet', 'Website', 'Template'];
const PRODUCT_TAGS = ['', 'BÁN CHẠY', 'MỚI', 'GIẢM GIÁ', 'MIỄN PHÍ'];

function blankProduct(): Product {
  return {
    id: '',
    name: '',
    type: 'Webapp',
    version: 'v1.0',
    price: 0,
    oldPrice: undefined,
    tag: '',
    shortDesc: '',
    description: '',
    features: [],
    thumbnail: '',
    gallery: [],
    fileUrl: '',
    fileName: '',
    active: true,
    featured: false,
    soldCount: 0,
    createdAt: 0,
    updatedAt: 0,
  };
}

interface VersionRow {
  name: string;
  price: string;
  oldPrice: string;
  note: string;
  fileUrl: string;
  fileName: string;
}

interface FormState {
  name: string;
  type: string;
  versions: VersionRow[];
  tag: string;
  shortDesc: string;
  description: string;
  features: string;
  thumbnail: string;
  gallery: string[];
  soldCount: string;
  active: boolean;
  featured: boolean;
}

function toRow(v: ProductVersion): VersionRow {
  return {
    name: v.name,
    price: String(v.price),
    oldPrice: v.oldPrice != null ? String(v.oldPrice) : '',
    note: v.note ?? '',
    fileUrl: v.fileUrl,
    fileName: v.fileName,
  };
}

function toForm(p: Product): FormState {
  return {
    name: p.name,
    type: p.type,
    versions: getVersions(p).map(toRow),
    tag: p.tag ?? '',
    shortDesc: p.shortDesc,
    description: p.description,
    features: p.features.join('\n'),
    thumbnail: p.thumbnail,
    gallery: [...p.gallery],
    soldCount: String(p.soldCount),
    active: p.active,
    featured: p.featured,
  };
}

function inputStyle(): React.CSSProperties {
  return { width: '100%', padding: '10px 12px', border: '1px solid #e0e6ea', borderRadius: 10 };
}

export default function Products() {
  const [list, setList] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState<FormState>(() => toForm(blankProduct()));
  const [formErr, setFormErr] = useState('');
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    setErr('');
    try {
      setList(await getAllProducts());
    } catch {
      setErr('Không tải được danh sách sản phẩm.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await getAllProducts();
        if (alive) setList(data);
      } catch {
        if (alive) setErr('Không tải được danh sách sản phẩm.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function setVer(idx: number, key: keyof VersionRow, value: string) {
    setForm((f) => ({
      ...f,
      versions: f.versions.map((v, i) => (i === idx ? { ...v, [key]: value } : v)),
    }));
  }

  function addVer() {
    setForm((f) => ({
      ...f,
      versions: [...f.versions, { name: '', price: '', oldPrice: '', note: '', fileUrl: '', fileName: '' }],
    }));
  }

  function removeVer(idx: number) {
    setForm((f) => ({ ...f, versions: f.versions.filter((_, i) => i !== idx) }));
  }

  // ----- Tải ảnh lên (Cloudinary) -----
  const { settings } = useStore();
  const thumbFileRef = useRef<HTMLInputElement>(null);
  const galleryFileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState<'' | 'thumb' | 'gallery'>('');
  const [uploadErr, setUploadErr] = useState('');
  const [galleryUrl, setGalleryUrl] = useState('');

  async function handleThumbFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setUploading('thumb');
    setUploadErr('');
    try {
      const url = await uploadImage(file, settings);
      set('thumbnail', url);
    } catch (ex) {
      setUploadErr(ex instanceof Error ? ex.message : 'Tải ảnh thất bại.');
    } finally {
      setUploading('');
    }
  }

  async function handleGalleryFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (files.length === 0) return;
    setUploading('gallery');
    setUploadErr('');
    try {
      const urls: string[] = [];
      for (const f of files) urls.push(await uploadImage(f, settings));
      setForm((fm) => ({ ...fm, gallery: [...fm.gallery, ...urls] }));
    } catch (ex) {
      setUploadErr(ex instanceof Error ? ex.message : 'Tải ảnh thất bại.');
    } finally {
      setUploading('');
    }
  }

  function addGalleryUrl() {
    const u = galleryUrl.trim();
    if (!u) return;
    setForm((fm) => ({ ...fm, gallery: [...fm.gallery, u] }));
    setGalleryUrl('');
  }

  function removeGallery(idx: number) {
    setForm((fm) => ({ ...fm, gallery: fm.gallery.filter((_, i) => i !== idx) }));
  }

  function openCreate() {
    setEditing(null);
    setForm(toForm(blankProduct()));
    setFormErr('');
    setShowModal(true);
  }

  function openEdit(p: Product) {
    setEditing(p);
    setForm(toForm(p));
    setFormErr('');
    setShowModal(true);
  }

  async function handleDelete(id: string, name: string) {
    if (!window.confirm(`Xóa sản phẩm "${name}"? Thao tác này không thể hoàn tác.`)) return;
    try {
      await deleteProduct(id);
      setList((l) => l.filter((p) => p.id !== id));
    } catch {
      alert('Xóa sản phẩm thất bại. Vui lòng thử lại.');
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setFormErr('');
    const name = form.name.trim();
    if (!name) {
      setFormErr('Vui lòng nhập tên sản phẩm.');
      return;
    }
    if (form.versions.length === 0) {
      setFormErr('Sản phẩm cần ít nhất 1 phiên bản.');
      return;
    }
    const versions: ProductVersion[] = [];
    for (let i = 0; i < form.versions.length; i++) {
      const row = form.versions[i];
      const vName = row.name.trim();
      if (!vName) {
        setFormErr(`Phiên bản ${i + 1}: chưa nhập tên phiên bản.`);
        return;
      }
      const vPrice = Number(row.price);
      if (row.price.trim() === '' || !Number.isFinite(vPrice) || vPrice < 0) {
        setFormErr(`Phiên bản ${i + 1}: giá bán không hợp lệ.`);
        return;
      }
      const vOld = row.oldPrice.trim() === '' ? undefined : Number(row.oldPrice);
      if (vOld !== undefined && (!Number.isFinite(vOld) || vOld < 0)) {
        setFormErr(`Phiên bản ${i + 1}: giá gốc không hợp lệ.`);
        return;
      }
      versions.push({
        name: vName,
        price: vPrice,
        oldPrice: vOld,
        note: row.note.trim() || undefined,
        fileUrl: row.fileUrl.trim(),
        fileName: row.fileName.trim(),
      });
    }
    const soldCount = Number(form.soldCount);
    if (!Number.isFinite(soldCount) || soldCount < 0) {
      setFormErr('Số lượt bán không hợp lệ.');
      return;
    }

    const id = editing?.id
      || unsignVietnamese(name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    if (!id) {
      setFormErr('Không tạo được mã sản phẩm từ tên. Hãy dùng tên có ký tự latin.');
      return;
    }

    setSaving(true);
    try {
      const first = versions[0];
      const p: Product = {
        ...(editing ?? blankProduct()),
        id,
        name,
        type: form.type,
        // Trường cũ được đồng bộ từ danh sách phiên bản để tương thích hiển thị:
        // version/file = phiên bản đầu, price = giá thấp nhất
        version: first.name,
        price: Math.min(...versions.map((v) => v.price)),
        oldPrice: first.oldPrice,
        versions,
        tag: form.tag || undefined,
        shortDesc: form.shortDesc.trim(),
        description: form.description.trim(),
        features: form.features.split('\n').map((s) => s.trim()).filter(Boolean),
        thumbnail: form.thumbnail.trim(),
        gallery: form.gallery.map((s) => s.trim()).filter(Boolean),
        fileUrl: first.fileUrl,
        fileName: first.fileName,
        soldCount: Math.floor(soldCount),
        active: form.active,
        featured: form.featured,
      };
      await saveProduct(p);
      setShowModal(false);
      await load();
    } catch (e) {
      setFormErr('Lưu sản phẩm thất bại' + (e instanceof Error ? `: ${e.message}` : '. Vui lòng thử lại.'));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div style={{ marginBottom: 16 }}>
        <button className="btn btn-green" onClick={openCreate}>
          <Icon name="plus" size={18} /> Thêm sản phẩm
        </button>
      </div>

      {err && <p className="f-err">{err}</p>}
      {loading ? (
        <p>Đang tải...</p>
      ) : list.length === 0 ? (
        <p className="empty">Chưa có sản phẩm nào. Nhấn "Thêm sản phẩm" để tạo mới.</p>
      ) : (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>Tên sản phẩm</th>
                <th>Giá</th>
                <th>Đã bán</th>
                <th>Trạng thái</th>
                <th>Nổi bật</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((p) => (
                <tr key={p.id}>
                  <td>
                    <b>{p.name}</b>
                    <div style={{ fontSize: 12.5, color: '#6b7684' }}>
                      {p.version} - {p.type}
                      {p.versions && p.versions.length > 1 ? ` - ${p.versions.length} phiên bản` : ''}
                    </div>
                  </td>
                  <td>
                    {p.versions && p.versions.length > 1 ? 'Từ ' : ''}
                    {fmtVND(p.price)}
                    {p.oldPrice != null && p.oldPrice > p.price && (
                      <div style={{ fontSize: 12.5, color: '#6b7684', textDecoration: 'line-through' }}>
                        {fmtVND(p.oldPrice)}
                      </div>
                    )}
                  </td>
                  <td>{p.soldCount}</td>
                  <td>
                    <span className={'status-pill ' + (p.active ? 'confirmed' : 'cancelled')}>
                      {p.active ? 'Đang bán' : 'Ẩn'}
                    </span>
                  </td>
                  <td>{p.featured ? <Icon name="check" size={18} /> : ''}</td>
                  <td>
                    <div className="row-actions">
                      <button className="mini-btn" onClick={() => openEdit(p)} title="Sửa">
                        <Icon name="edit" size={16} /> Sửa
                      </button>
                      <button className="mini-btn red" onClick={() => handleDelete(p.id, p.name)} title="Xóa">
                        <Icon name="trash" size={16} /> Xóa
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 640 }}>
            <div className="modal-head">
              <h3>{editing ? 'Sửa sản phẩm' : 'Thêm sản phẩm'}</h3>
              <button className="icon-btn" onClick={() => setShowModal(false)} aria-label="Đóng">
                <Icon name="x" size={20} />
              </button>
            </div>
            <div className="modal-body">
              <form onSubmit={handleSave} className="form-grid">
                <div>
                  <label className="f-label">Tên sản phẩm *</label>
                  <input value={form.name} onChange={(e) => set('name', e.target.value)} style={inputStyle()} placeholder="VD: Beesy Trọ" />
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <div>
                    <label className="f-label">Loại</label>
                    <select value={form.type} onChange={(e) => set('type', e.target.value)} style={inputStyle()}>
                      {PRODUCT_TYPES.map((t) => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="f-label">Nhãn nổi bật</label>
                    <select value={form.tag} onChange={(e) => set('tag', e.target.value)} style={inputStyle()}>
                      {PRODUCT_TAGS.map((t) => (
                        <option key={t} value={t}>{t === '' ? '(Không có)' : t}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="f-label">Phiên bản & giá *</label>
                  <p className="f-hint" style={{ marginTop: 0, marginBottom: 8 }}>
                    Mỗi phiên bản có giá và file giao riêng - khách chọn phiên bản ở trang sản phẩm rồi thanh toán theo giá đó.
                    Phiên bản đầu tiên là bản mặc định.
                  </p>
                  {form.versions.map((v, i) => (
                    <div key={i} className="ver-row">
                      <div className="ver-row-head">
                        <b>Phiên bản {i + 1}</b>
                        {form.versions.length > 1 && (
                          <button type="button" className="mini-btn red" onClick={() => removeVer(i)}>
                            <Icon name="trash" size={14} /> Xóa
                          </button>
                        )}
                      </div>
                      <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                        <div>
                          <label className="f-label">Tên phiên bản *</label>
                          <input value={v.name} onChange={(e) => setVer(i, 'name', e.target.value)} style={inputStyle()} placeholder="VD: v2.7 (bản mới nhất)" />
                        </div>
                        <div>
                          <label className="f-label">Ghi chú ngắn</label>
                          <input value={v.note} onChange={(e) => setVer(i, 'note', e.target.value)} style={inputStyle()} placeholder="VD: Đầy đủ tính năng + hỗ trợ 12 tháng" />
                        </div>
                      </div>
                      <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                        <div>
                          <label className="f-label">Giá bán (đ) *</label>
                          <input type="number" min={0} value={v.price} onChange={(e) => setVer(i, 'price', e.target.value)} style={inputStyle()} placeholder="0 = miễn phí" />
                        </div>
                        <div>
                          <label className="f-label">Giá gốc (đ)</label>
                          <input type="number" min={0} value={v.oldPrice} onChange={(e) => setVer(i, 'oldPrice', e.target.value)} style={inputStyle()} placeholder="Để trống nếu không giảm giá" />
                        </div>
                      </div>
                      <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                        <div>
                          <label className="f-label">Link file giao (phiên bản này)</label>
                          <input value={v.fileUrl} onChange={(e) => setVer(i, 'fileUrl', e.target.value)} style={inputStyle()} placeholder="Link Drive / file zip" />
                        </div>
                        <div>
                          <label className="f-label">Tên file hiển thị</label>
                          <input value={v.fileName} onChange={(e) => setVer(i, 'fileName', e.target.value)} style={inputStyle()} placeholder="VD: beesy-tro-v2.7.zip" />
                        </div>
                      </div>
                    </div>
                  ))}
                  <button type="button" className="btn btn-outline btn-sm" onClick={addVer}>
                    <Icon name="plus" size={15} /> Thêm phiên bản
                  </button>
                </div>
                <div>
                  <label className="f-label">Đã bán</label>
                  <input type="number" min={0} value={form.soldCount} onChange={(e) => set('soldCount', e.target.value)} style={inputStyle()} />
                </div>
                <div>
                  <label className="f-label">Mô tả ngắn</label>
                  <input value={form.shortDesc} onChange={(e) => set('shortDesc', e.target.value)} style={inputStyle()} placeholder="Một câu giới thiệu trên thẻ sản phẩm" />
                </div>
                <div>
                  <label className="f-label">Mô tả chi tiết</label>
                  <RichTextEditor
                    value={form.description}
                    onChange={(html) => set('description', html)}
                    settings={settings}
                  />
                </div>
                <div>
                  <label className="f-label">Tính năng nổi bật</label>
                  <textarea rows={4} value={form.features} onChange={(e) => set('features', e.target.value)} style={inputStyle()} placeholder="Mỗi dòng một tính năng" />
                  <p className="f-hint">Mỗi dòng một tính năng.</p>
                </div>
                <div>
                  <label className="f-label">Ảnh đại diện</label>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', flexWrap: 'wrap' }}>
                    <input value={form.thumbnail} onChange={(e) => set('thumbnail', e.target.value)} style={{ ...inputStyle(), flex: 1, minWidth: 200 }} placeholder="Dán link ảnh https://... hoặc bấm Tải ảnh lên" />
                    <button type="button" className="btn btn-outline btn-sm" onClick={() => thumbFileRef.current?.click()} disabled={uploading === 'thumb'}>
                      <Icon name="image" size={15} /> {uploading === 'thumb' ? 'Đang tải...' : 'Tải ảnh lên'}
                    </button>
                  </div>
                  <input ref={thumbFileRef} type="file" accept="image/*" hidden onChange={handleThumbFile} />
                  {form.thumbnail && (
                    <img src={form.thumbnail} alt="Ảnh đại diện" style={{ marginTop: 10, width: 150, height: 110, objectFit: 'cover', borderRadius: 10, border: '1px solid #e0e6ea' }} />
                  )}
                </div>
                <div>
                  <label className="f-label">Ảnh minh họa thêm (thư viện)</label>
                  {form.gallery.length > 0 && (
                    <div className="gal-edit">
                      {form.gallery.map((g, i) => (
                        <div key={i} className="gal-item">
                          <img src={g} alt={`Ảnh minh họa ${i + 1}`} />
                          <button type="button" onClick={() => removeGallery(i)} aria-label="Xóa ảnh">
                            <Icon name="x" size={13} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: form.gallery.length ? 10 : 0 }}>
                    <input value={galleryUrl} onChange={(e) => setGalleryUrl(e.target.value)} style={{ ...inputStyle(), flex: 1, minWidth: 200 }} placeholder="Dán link ảnh rồi bấm Thêm" />
                    <button type="button" className="btn btn-ghost btn-sm" onClick={addGalleryUrl}>
                      <Icon name="plus" size={15} /> Thêm link
                    </button>
                    <button type="button" className="btn btn-outline btn-sm" onClick={() => galleryFileRef.current?.click()} disabled={uploading === 'gallery'}>
                      <Icon name="image" size={15} /> {uploading === 'gallery' ? 'Đang tải...' : 'Tải ảnh lên'}
                    </button>
                  </div>
                  <input ref={galleryFileRef} type="file" accept="image/*" multiple hidden onChange={handleGalleryFiles} />
                  {uploadErr && <p className="f-err">{uploadErr}</p>}
                  {!isUploadConfigured(settings) && (
                    <p className="f-hint">Muốn tải ảnh trực tiếp từ máy: vào Cài đặt, mục "Tải ảnh lên (Cloudinary)" để điền cấu hình. Chưa có vẫn dán link ảnh được.</p>
                  )}
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <label className="check-row">
                    <input type="checkbox" checked={form.active} onChange={(e) => set('active', e.target.checked)} />
                    Đang bán
                  </label>
                  <label className="check-row">
                    <input type="checkbox" checked={form.featured} onChange={(e) => set('featured', e.target.checked)} />
                    Nổi bật
                  </label>
                </div>
                {formErr && <p className="f-err">{formErr}</p>}
                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                  <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>
                    Hủy
                  </button>
                  <button type="submit" className="btn btn-green" disabled={saving}>
                    {saving ? 'Đang lưu...' : 'Lưu sản phẩm'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
