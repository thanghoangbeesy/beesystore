// Trang Cài đặt shop (thông tin liên hệ, ngân hàng, hero, admin UID)
import { useEffect, useState } from 'react';
import { getSettings, saveSettings } from '../../lib/db';
import type { StoreSettings } from '../../lib/types';
import { useStore } from '../../lib/store';
import { Icon } from '../../components/Icon';

function inputStyle(): React.CSSProperties {
  return { width: '100%', padding: '10px 12px', border: '1px solid #e0e6ea', borderRadius: 10 };
}

export default function SettingsPage() {
  const { demo } = useStore();
  const [form, setForm] = useState<StoreSettings | null>(null);
  const [adminUidsText, setAdminUidsText] = useState('');
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const s = await getSettings();
        if (alive) {
          setForm(s);
          setAdminUidsText((s.adminUids ?? []).join('\n'));
        }
      } catch {
        if (alive) setErr('Không tải được cài đặt.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  function set<K extends keyof StoreSettings>(key: K, value: StoreSettings[K]) {
    setForm((f) => (f ? { ...f, [key]: value } : f));
    setSaved(false);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setErr('');
    setSaving(true);
    try {
      const adminUids = adminUidsText
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean);
      const data: StoreSettings = { ...form, adminUids };
      await saveSettings(data);
      setForm(data);
      setSaved(true);
    } catch {
      setErr('Lưu cài đặt thất bại. Vui lòng thử lại.');
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <p>Đang tải...</p>;
  if (!form) return <p className="f-err">{err || 'Không tải được cài đặt.'}</p>;

  return (
    <form onSubmit={handleSave}>
      {demo && (
        <p className="f-hint" style={{ marginBottom: 14 }}>
          Chế độ demo - lưu trên trình duyệt.
        </p>
      )}

      <div className="panel">
        <h3>Thông tin shop</h3>
        <div className="form-grid">
          <div>
            <label className="f-label">Tên shop</label>
            <input value={form.shopName} onChange={(e) => set('shopName', e.target.value)} style={inputStyle()} />
          </div>
          <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <div>
              <label className="f-label">Hotline</label>
              <input value={form.hotline} onChange={(e) => set('hotline', e.target.value)} style={inputStyle()} />
            </div>
            <div>
              <label className="f-label">Zalo</label>
              <input value={form.zalo} onChange={(e) => set('zalo', e.target.value)} style={inputStyle()} placeholder="Số điện thoại Zalo" />
            </div>
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>Tài khoản ngân hàng nhận tiền</h3>
        <div className="form-grid">
          <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <div>
              <label className="f-label">Mã BIN ngân hàng</label>
              <input value={form.bankBin} onChange={(e) => set('bankBin', e.target.value)} style={inputStyle()} placeholder="VD: 970422 (MBBank)" />
            </div>
            <div>
              <label className="f-label">Số tài khoản</label>
              <input value={form.bankAccount} onChange={(e) => set('bankAccount', e.target.value)} style={inputStyle()} />
            </div>
          </div>
          <div>
            <label className="f-label">Tên chủ tài khoản</label>
            <input value={form.bankAccountName} onChange={(e) => set('bankAccountName', e.target.value)} style={inputStyle()} />
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>Banner khuyến mãi</h3>
        <div className="form-grid">
          <div>
            <label className="f-label">Nội dung banner</label>
            <input value={form.bannerText} onChange={(e) => set('bannerText', e.target.value)} style={inputStyle()} placeholder="VD: Giảm 40% khi mua Beesy POS trong tháng này" />
          </div>
          <label className="check-row">
            <input
              type="checkbox"
              checked={form.bannerActive}
              onChange={(e) => set('bannerActive', e.target.checked)}
            />
            Hiển thị banner trên trang chủ
          </label>
        </div>
      </div>

      <div className="panel">
        <h3>Mục giới thiệu (hero)</h3>
        <div className="form-grid">
          <div>
            <label className="f-label">Tiêu đề</label>
            <input value={form.heroTitle} onChange={(e) => set('heroTitle', e.target.value)} style={inputStyle()} />
          </div>
          <div>
            <label className="f-label">Mô tả</label>
            <textarea rows={3} value={form.heroSubtitle} onChange={(e) => set('heroSubtitle', e.target.value)} style={inputStyle()} />
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>Tải ảnh lên (Cloudinary)</h3>
        <div className="form-grid">
          <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <div>
              <label className="f-label">Cloud name</label>
              <input value={form.cloudName} onChange={(e) => set('cloudName', e.target.value)} style={inputStyle()} placeholder="VD: dxxxxxxx" />
            </div>
            <div>
              <label className="f-label">Upload preset (unsigned)</label>
              <input value={form.uploadPreset} onChange={(e) => set('uploadPreset', e.target.value)} style={inputStyle()} placeholder="Tên preset" />
            </div>
          </div>
          <p className="f-hint">
            Điền 2 giá trị này để bật nút "Tải ảnh lên" trong phần Sản phẩm (ảnh đại diện, thư viện ảnh, chèn ảnh vào mô tả).
            Có thể dùng đúng tài khoản Cloudinary của web lớp LittleBees: vào cloudinary.com, mục Settings, Upload, xem cloud name ở Dashboard và preset dạng Unsigned.
            Chưa điền vẫn dán link ảnh trực tiếp được như trước.
          </p>
        </div>
      </div>

      <div className="panel">
        <h3>Tài khoản quản trị</h3>
        <div className="form-grid">
          <div>
            <label className="f-label">Danh sách UID admin</label>
            <textarea
              rows={3}
              value={adminUidsText}
              onChange={(e) => setAdminUidsText(e.target.value)}
              style={{ ...inputStyle(), fontFamily: 'monospace' }}
              placeholder="Mỗi dòng một UID"
            />
            <p className="f-hint">
              Lấy UID tại Firebase Console, mục Authentication, mục Users, copy UID; mỗi dòng một UID.
            </p>
          </div>
        </div>
      </div>

      {err && <p className="f-err">{err}</p>}
      <button type="submit" className="btn btn-green" disabled={saving}>
        <Icon name="check" size={18} /> {saving ? 'Đang lưu...' : 'Lưu cài đặt'}
      </button>
      {saved && <p className="f-hint" style={{ color: '#00a651', fontWeight: 700, marginTop: 10 }}>Đã lưu cài đặt.</p>}
    </form>
  );
}
