// Layout trang quản trị Beesy Store (sidebar + topbar + outlet)
import { NavLink, Navigate, Outlet, useLocation } from 'react-router-dom';
import { signOut } from 'firebase/auth';
import { auth as getAuth } from '../../lib/firebase';
import { useStore } from '../../lib/store';
import { Icon } from '../../components/Icon';

const DEMO_KEY = 'beesystore_demo_admin';

const NAV = [
  { to: '/admin', label: 'Tổng quan', icon: 'grid' as const, title: 'Tổng quan' },
  { to: '/admin/san-pham', label: 'Sản phẩm', icon: 'box' as const, title: 'Sản phẩm' },
  { to: '/admin/don-hang', label: 'Đơn hàng', icon: 'receipt' as const, title: 'Đơn hàng' },
  { to: '/admin/voucher', label: 'Voucher', icon: 'ticket' as const, title: 'Voucher' },
  { to: '/admin/cai-dat', label: 'Cài đặt', icon: 'settings' as const, title: 'Cài đặt' },
];

export default function AdminLayout() {
  const { user, isAdmin, loading, demo } = useStore();
  const location = useLocation();

  async function handleLogout() {
    if (demo) {
      localStorage.removeItem(DEMO_KEY);
      window.location.href = '/admin/login';
      return;
    }
    await signOut(getAuth());
  }

  if (loading) return <p style={{ padding: 24 }}>Đang tải...</p>;
  if (!user) return <Navigate to="/admin/login" replace />;

  if (!isAdmin) {
    return (
      <div className="login-wrap">
        <div className="panel" style={{ maxWidth: 420 }}>
          <h3>Tài khoản không có quyền quản trị</h3>
          <p style={{ color: '#6b7684', marginBottom: 16 }}>
            Tài khoản <b>{user.email}</b> chưa được cấp quyền quản trị. Vui lòng liên hệ chủ shop.
          </p>
          <button className="btn btn-outline" onClick={handleLogout}>
            Đăng xuất
          </button>
        </div>
      </div>
    );
  }

  const current = [...NAV].reverse().find((n) => location.pathname.startsWith(n.to) && n.to !== '/admin')
    ?? (location.pathname === '/admin' ? NAV[0] : undefined);
  const title = current?.title ?? 'Trang quản trị';

  return (
    <div className="admin-shell">
      <aside className="admin-side">
        <div className="logo">
          <b>Beesy Store</b>
        </div>
        <nav>
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === '/admin'}>
              <Icon name={n.icon} size={18} />
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div style={{ marginTop: 'auto', paddingTop: 18 }}>
          {demo && (
            <p className="f-hint" style={{ color: 'rgba(255,255,255,.65)', marginBottom: 10 }}>
              Chế độ demo - dữ liệu lưu trên trình duyệt.
            </p>
          )}
          <button
            className="btn btn-ghost btn-block"
            onClick={handleLogout}
            style={{ display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center' }}
          >
            <Icon name="logout" size={18} />
            Đăng xuất
          </button>
        </div>
      </aside>

      <div className="admin-main">
        <header className="admin-top">
          <h2>{title}</h2>
          <span style={{ fontSize: 13.5, color: '#6b7684' }}>{user.email}</span>
        </header>
        <nav className="admin-tabs">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === '/admin'} className={({ isActive }) => (isActive ? 'active' : '')}>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="admin-body">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
