import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { getActiveProducts } from '../lib/db';
import { useStore } from '../lib/store';
import type { Product } from '../lib/types';
import { unsignVietnamese } from '../lib/format';
import { ProductCard } from '../components/ProductCard';
import { ProductThumb } from '../components/ProductThumb';
import { Icon } from '../components/Icon';

function Hero() {
  const { settings } = useStore();
  const words = settings.heroTitle.split(' ');
  const head = words.slice(0, 3).join(' ');
  const tail = words.slice(3).join(' ');
  return (
    <section className="hero">
      <div className="wrap">
        <div className="hero-inner">
          <div>
            <div className="hero-badge">
              <Icon name="bolt" size={15} /> Mua một lần - dùng vĩnh viễn
            </div>
            <h1>
              {head} {tail && <span className="hl-green">{tail}</span>}
            </h1>
            <p className="sub">{settings.heroSubtitle}</p>
            <div className="hero-cta">
              <a href="#san-pham" className="btn btn-green">
                <Icon name="grid" size={18} /> Xem sản phẩm
              </a>
              <Link to="/tra-cuu" className="btn btn-outline">
                <Icon name="receipt" size={18} /> Tra cứu đơn hàng
              </Link>
            </div>
            <div className="hero-stats">
              <div className="stat">
                <b>3+</b>
                <span>Sản phẩm chất lượng</span>
              </div>
              <div className="stat">
                <b>24/7</b>
                <span>Hỗ trợ kỹ thuật</span>
              </div>
              <div className="stat">
                <b>1 lần</b>
                <span>Thanh toán duy nhất</span>
              </div>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <HeroFloatCards />
          </div>
        </div>
      </div>
    </section>
  );
}

function HeroFloatCards() {
  const [products, setProducts] = useState<Product[]>([]);
  useEffect(() => {
    getActiveProducts().then(setProducts).catch(() => {});
  }, []);
  const cards = products.slice(0, 3);
  const pos = ['c1', 'c2', 'c3'];
  return (
    <>
      {cards.map((p, i) => (
        <div key={p.id} className={`hero-card-float ${pos[i % 3]}`}>
          <span className="thumb">
            <ProductThumb type={p.type} thumbnail="" size={26} />
          </span>
          <span>
            <b>{p.name}</b>
            <span>
              {p.type} - {p.version}
            </span>
          </span>
        </div>
      ))}
    </>
  );
}

export function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [params] = useSearchParams();
  const q = params.get('q')?.trim() || '';

  useEffect(() => {
    getActiveProducts()
      .then(setProducts)
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    if (!q) return products;
    const needle = unsignVietnamese(q).toLowerCase();
    return products.filter((p) =>
      unsignVietnamese(`${p.name} ${p.type} ${p.shortDesc}`).toLowerCase().includes(needle),
    );
  }, [products, q]);

  return (
    <>
      <Hero />
      <section className="section" id="san-pham">
        <div className="wrap">
          <div className="section-head">
            <div>
              <h2>{q ? `Kết quả tìm kiếm: "${q}"` : 'Sản phẩm nổi bật'}</h2>
              <p>Webapp, Google Sheet và website làm sẵn - thanh toán một lần, sở hữu trọn đời.</p>
            </div>
          </div>
          {loading ? (
            <div className="empty">
              <Icon name="refresh" size={40} />
              <p>Đang tải sản phẩm...</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="empty">
              <Icon name="search" size={40} />
              <p>Không tìm thấy sản phẩm phù hợp.</p>
            </div>
          ) : (
            <div className="product-grid">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </section>
      <WhyUs />
    </>
  );
}

function WhyUs() {
  const { settings } = useStore();
  const items = [
    { icon: 'wallet' as const, t: 'Mua một lần, dùng vĩnh viễn', d: 'Không phí thuê bao hằng tháng. Trả một lần, sở hữu trọn đời.' },
    { icon: 'bolt' as const, t: 'Nhận file nhanh chóng', d: 'Thanh toán chuyển khoản, shop xác nhận và gửi file + hướng dẫn ngay.' },
    { icon: 'lifebuoy' as const, t: 'Hỗ trợ tận tay', d: `Người trực tiếp làm ra sản phẩm hỗ trợ bạn qua Zalo ${settings.zalo}.` },
    { icon: 'shield' as const, t: 'Cập nhật dài hạn', d: 'Được nhận các bản cập nhật mới và hỗ trợ kỹ thuật chu đáo.' },
  ];
  return (
    <section className="section" style={{ background: 'var(--bg-soft)', borderTop: '1px solid var(--line)' }}>
      <div className="wrap">
        <div className="section-head">
          <div>
            <h2>Vì sao mua tại Beesy Store?</h2>
            <p>Sản phẩm do chính chủ shop làm ra và dùng mỗi ngày.</p>
          </div>
        </div>
        <div className="product-grid">
          {items.map((it) => (
            <div className="panel" key={it.t} style={{ margin: 0 }}>
              <div style={{ color: 'var(--green)', marginBottom: 10 }}>
                <Icon name={it.icon} size={30} strokeWidth={1.5} />
              </div>
              <h3 style={{ fontSize: 16, marginBottom: 6 }}>{it.t}</h3>
              <p style={{ fontSize: 14, color: 'var(--muted)' }}>{it.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
