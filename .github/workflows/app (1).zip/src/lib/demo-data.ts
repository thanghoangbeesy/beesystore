// Dữ liệu mẫu cho Beesy Store - dùng cho chế độ demo (chưa cấu hình Firebase)
// và làm nguồn cho script seed. Nội dung 100% tự viết, không sao chép từ bất kỳ đâu.
import type { Product, StoreSettings, Voucher } from './types';

const now = Date.now();

export const demoProducts: Product[] = [
  {
    id: 'beesy-pos',
    name: 'Beesy POS',
    type: 'Webapp',
    version: 'v5.0',
    price: 990000, // giá thấp nhất trong các phiên bản (hiển thị "Từ ...")
    versions: [
      {
        name: 'v5.0',
        price: 1490000, // TODO: Hoàng chốt giá chính thức
        note: 'Bản mới nhất - đầy đủ tính năng',
        fileUrl: '',
        fileName: 'beesy-pos-v5.zip',
      },
      {
        name: 'v1.0',
        price: 990000, // TODO: Hoàng chốt giá chính thức
        note: 'Bản Final v1 ổn định',
        fileUrl: '',
        fileName: 'beesy-pos-v1.zip',
      },
    ],
    tag: 'BÁN CHẠY',
    shortDesc:
      'Webapp bán hàng cho quán cafe, trà sữa: thu ngân tại quầy, quản lý menu, kho và báo cáo.',
    description:
      'Beesy POS là webapp bán hàng được xây dựng từ chính nhu cầu vận hành quán cafe mỗi ngày: ' +
      'chạm là bán, không rườm rà. Giao diện gọn, hiện đại, chạy mượt trên điện thoại, tablet và máy tính.\n\n' +
      'Bạn nhận được toàn bộ mã nguồn kèm hướng dẫn cài đặt từng bước trên điện thoại - ' +
      'không cần biết lập trình vẫn triển khai được. Mua một lần, dùng vĩnh viễn, không phí thuê bao hằng tháng.',
    features: [
      'Bán hàng tại quầy, in hóa đơn có mã QR thanh toán',
      'Quản lý menu, danh mục, giá bán theo size/topping',
      'Quản lý kho đa kho, phiếu nhập/xuất, cảnh báo hết hàng',
      'Báo cáo doanh thu, lợi nhuận theo ngày/tuần/tháng',
      'Quản lý khách hàng, công nợ, tích điểm đổi thưởng',
      'Sổ quỹ thu chi, phân quyền nhân viên theo ca',
      'Chạy tốt trên điện thoại, tablet và PC',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng
    fileName: 'beesy-pos-v5.zip',
    active: true,
    featured: true,
    soldCount: 12,
    createdAt: now,
    updatedAt: now,
  },
  {
    id: 'beesy-tro',
    name: 'Beesy Trọ',
    type: 'Google Sheet',
    version: 'v2.7',
    price: 0, // giá thấp nhất trong các phiên bản (có bản v1 miễn phí)
    versions: [
      {
        name: 'v2.7',
        price: 469000,
        note: 'Bản mới nhất - cập nhật & hỗ trợ 12 tháng',
        fileUrl: '',
        fileName: 'beesy-tro-v2.zip',
      },
      {
        name: 'v1',
        price: 0,
        note: 'Bản miễn phí, không cập nhật',
        fileUrl: '',
        fileName: 'beesy-tro-v1.zip',
      },
    ],
    tag: 'BÁN CHẠY',
    shortDesc:
      'Quản lý nhà trọ trên Google Sheet: phòng, khách thuê, điện nước, hóa đơn và sổ quỹ.',
    description:
      'Beesy Trọ giúp chủ trọ quản lý cả dãy phòng ngay trên Google Sheet quen thuộc - ' +
      'không cần cài app, không cần máy chủ. Mọi thứ chạy tự động: chốt chỉ số điện nước, ' +
      'lập hóa đơn có mã QR chuyển khoản, gửi hóa đơn qua Zalo cho khách thuê.\n\n' +
      'Mua một lần dùng trọn đời, được cập nhật các bản mới và hỗ trợ kỹ thuật 12 tháng.',
    features: [
      'Quản lý phòng, khách thuê, hợp đồng thuê',
      'Ghi chỉ số điện nước, tự tính tiền theo từng kỳ',
      'Xuất hóa đơn có mã QR chuyển khoản VietQR',
      'Gửi hóa đơn cho khách qua Zalo trong 1 chạm',
      'Sổ quỹ thu chi, quản lý tiền cọc, tài sản',
      'Báo cáo doanh thu theo tháng/năm, xuất Excel',
      'Chạy trên Google Sheet - không cần cài đặt gì thêm',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng
    fileName: 'beesy-tro-v2.zip',
    active: true,
    featured: true,
    soldCount: 30,
    createdAt: now,
    updatedAt: now,
  },
  {
    id: 'littlebees',
    name: 'Beesy Class',
    type: 'Website',
    version: 'v3.0',
    price: 990000, // TODO: Hoàng chốt giá chính thức
    tag: 'MỚI',
    shortDesc:
      'Website cho lớp tiền tiểu học: bài học, game tương tác, album ảnh và quản lý học sinh.',
    description:
      'Beesy Class là website dành cho lớp tiền tiểu học với giao diện tươi sáng, thân thiện với trẻ. ' +
      'Cô giáo đăng bài học, tổ chức game tương tác ngay trên lớp; phụ huynh theo dõi tiến trình, ' +
      'điểm danh và học phí của con qua tài khoản riêng.\n\n' +
      'Bạn nhận toàn bộ mã nguồn kèm hướng dẫn triển khai chi tiết. Mua một lần, dùng vĩnh viễn.',
    features: [
      'Trang lớp học với bài học theo 4 dạng: đọc, xem, nghe, viết',
      '4 game tương tác cho bé chơi trực tiếp trên lớp',
      'Album ảnh, video hoạt động của lớp',
      'Tài khoản phụ huynh: xem điểm danh, tiến trình, học phí',
      'Quản lý học sinh, học phí theo lớp/kỳ',
      'Bảng tin, form đăng ký học thử, vinh danh bé ngoan',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng
    fileName: 'littlebees-v3.zip',
    active: true,
    featured: true,
    soldCount: 5,
    createdAt: now,
    updatedAt: now,
  },
  {
    id: 'beesy-ns',
    name: 'Beesy Nhân Sự',
    type: 'File HTML',
    version: 'v1.0',
    price: 0,
    versions: [
      {
        name: 'v1.0',
        price: 0,
        note: 'Bản tặng miễn phí - 1 file HTML duy nhất',
        fileUrl: '',
        fileName: 'beesy-ns-v1.0.zip',
      },
    ],
    tag: 'MIỄN PHÍ',
    shortDesc:
      'Chấm công và tính lương cho doanh nghiệp nhỏ theo luật 2026, mở file HTML là dùng ngay, không cần cài đặt.',
    description:
      'Beesy Nhân Sự là file HTML duy nhất giúp doanh nghiệp nhỏ chấm công và tính lương mà không cần cài đặt ' +
      'phần mềm hay tạo tài khoản: mở file bằng trình duyệt là dùng được ngay, dữ liệu lưu trên máy của bạn.\n\n' +
      'Bảng lương tự tính theo luật 2026: công chuẩn 26 ngày, làm thêm giờ 3 hệ số 150/200/300%, ' +
      'giảm trừ bản thân 15.500.000đ và người phụ thuộc 6.200.000đ, biểu thuế 5 bậc mới, trần đóng BHXH/BHYT ' +
      'và BHTN đúng quy định. Lưu ý: bản v1.0 dùng chữ không dấu để tránh lỗi font trên mọi máy.',
    features: [
      'Quản lý nhân viên, nhập danh sách từ Excel/CSV',
      'Chấm công bấm hoặc kéo chuột qua các ô ngày',
      'Bảng lương tự tính theo luật 2026',
      'Phiếu lương in ra giấy hoặc chép nội dung gửi Zalo',
      'Bảng trích nộp BHXH, BHYT, BHTN và kinh phí công đoàn',
      'Báo cáo quỹ lương theo phòng ban, xu hướng 12 tháng',
      'Sao lưu JSON, tải file HTML kèm dữ liệu, dữ liệu mẫu 12 nhân viên',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng (beesy-ns-v1.0.zip)
    fileName: 'beesy-ns-v1.0.zip',
    active: true,
    featured: true,
    soldCount: 0,
    createdAt: now,
    updatedAt: now,
  },
  {
    id: 'beesy-cong-viec',
    name: 'Beesy Công Việc',
    type: 'File HTML',
    version: 'v1.0',
    price: 0,
    versions: [
      {
        name: 'v1.0',
        price: 0,
        note: 'Bản tặng miễn phí - 1 file HTML duy nhất',
        fileUrl: '',
        fileName: 'beesy-cong-viec-v1.0.zip',
      },
    ],
    tag: 'MIỄN PHÍ',
    shortDesc:
      'Quản lý công việc kèm biểu đồ Gantt kéo thả, nhiều dự án, in A4, chạy offline bằng 1 file HTML.',
    description:
      'Beesy Công Việc là file HTML duy nhất để quản lý công việc kèm biểu đồ Gantt: mở file bằng trình duyệt ' +
      'là dùng được ngay, không cần mạng, không cần tài khoản, không link ngoài.\n\n' +
      'Kéo thanh Gantt để dời ngày, kéo mép để đổi số ngày, việc phụ thuộc tự dời theo dây chuyền, ' +
      'trạng thái và cảnh báo chậm tự cập nhật. Dữ liệu lưu trên trình duyệt, sao lưu và khôi phục bằng file JSON.',
    features: [
      'Biểu đồ Gantt xem theo ngày/tuần/tháng, kéo thả đổi ngày',
      'Kế hoạch công việc: thêm, sửa, nhân bản, xóa, mức ưu tiên, việc phải làm trước',
      'Nhiều dự án, nhân bản dự án giữ nguyên quan hệ việc trước',
      'Thống kê nhân sự: số việc, việc trễ, tiến độ từng người',
      'Cảnh báo việc chậm khi thực tế thấp hơn kế hoạch hơn 15 điểm',
      'In biểu đồ Gantt ngang khổ A4, xuất kế hoạch ra CSV mở đúng tiếng Việt bằng Excel',
      'Sao lưu và khôi phục JSON, dữ liệu mẫu 1 dự án 8 việc',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng (beesy-cong-viec-v1.0.zip)
    fileName: 'beesy-cong-viec-v1.0.zip',
    active: true,
    featured: true,
    soldCount: 0,
    createdAt: now,
    updatedAt: now,
  },
];

export const demoSettings: StoreSettings = {
  shopName: 'Beesy Store',
  hotline: '0876 791 593',
  zalo: '0876 791 593',
  bankBin: '', // TODO: Hoàng điền mã BIN ngân hàng nhận tiền
  bankAccount: '', // TODO: Hoàng điền STK
  bankAccountName: '', // TODO: Hoàng điền chủ tài khoản
  bannerText: 'Khai trương Beesy Store - Ưu đãi đến 40% cho các gói trả phí',
  bannerActive: true,
  heroTitle: 'Kho webapp & template cho công việc của bạn',
  heroSubtitle:
    'Mua một lần, dùng vĩnh viễn. Thanh toán chuyển khoản nhanh gọn - nhận file ngay sau khi shop xác nhận.',
  adminUids: [],
  cloudName: '', // TODO: Hoàng điền Cloudinary cloud name (dùng chung tài khoản web lớp)
  uploadPreset: '', // TODO: Hoàng điền unsigned upload preset của Cloudinary
};

export const demoVouchers: Voucher[] = [
  {
    id: 'v-mau',
    code: 'MẪU-10',
    type: 'percent',
    value: 10,
    maxDiscount: 100000,
    usedCount: 0,
    active: false, // voucher mẫu (tắt) để admin tham khảo cách tạo
  },
];

export const ORDER_SEQ_START = 100000;
