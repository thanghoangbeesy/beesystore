// Tầng dữ liệu Beesy Store: Firestore khi đã cấu hình, localStorage khi ở chế độ demo.
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  runTransaction,
  serverTimestamp,
} from 'firebase/firestore';
import { db as fdb, isConfigured } from './firebase';
import { demoProducts, demoSettings, demoVouchers, ORDER_SEQ_START } from './demo-data';
import type { Order, OrderStatus, Product, StoreSettings, Voucher } from './types';
import { normalizePhone } from './format';

const DEMO = !isConfigured();
export const isDemoMode = DEMO;

/**
 * Firestore TU CHOI gia tri undefined ("Unsupported field value: undefined").
 * Cac truong tuy chon de trong (gia goc, ghi chu, voucher...) se sinh undefined,
 * nen moi du lieu ghi len Firestore phai qua ham nay de loai bo sau cac key undefined.
 * Chi xu ly object thuong + mang; gia tri dac biet cua Firestore (serverTimestamp...)
 * va class instance duoc giu nguyen.
 */
function stripUndefined<T>(value: T): T {
  if (Array.isArray(value)) return value.map((v) => stripUndefined(v)) as T;
  if (value && typeof value === 'object') {
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) return value;
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v !== undefined) out[k] = stripUndefined(v);
    }
    return out as T;
  }
  return value;
}

// ---------- Demo backend (localStorage) ----------
const LS = {
  products: 'beesystore_demo_products',
  settings: 'beesystore_demo_settings',
  vouchers: 'beesystore_demo_vouchers',
  orders: 'beesystore_demo_orders',
  seq: 'beesystore_demo_seq',
};
function lsGet<T>(k: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(k);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function lsSet(k: string, v: unknown) {
  localStorage.setItem(k, JSON.stringify(v));
}
function demoSeed() {
  if (!localStorage.getItem(LS.products)) {
    lsSet(LS.products, demoProducts);
    lsSet(LS.settings, demoSettings);
    lsSet(LS.vouchers, demoVouchers);
    lsSet(LS.orders, []);
    lsSet(LS.seq, ORDER_SEQ_START);
  }
}
if (DEMO && typeof localStorage !== 'undefined') demoSeed();

// ---------- Products ----------
export async function getActiveProducts(): Promise<Product[]> {
  if (DEMO) return (lsGet<Product[]>(LS.products, [])).filter((p) => p.active);
  const q = query(collection(fdb(), 'products'), where('active', '==', true));
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Product);
}
export async function getAllProducts(): Promise<Product[]> {
  if (DEMO) return lsGet<Product[]>(LS.products, []);
  const snap = await getDocs(collection(fdb(), 'products'));
  return snap.docs.map((d) => d.data() as Product);
}
export async function getProduct(id: string): Promise<Product | null> {
  if (DEMO) return lsGet<Product[]>(LS.products, []).find((p) => p.id === id) ?? null;
  const snap = await getDoc(doc(fdb(), 'products', id));
  return snap.exists() ? (snap.data() as Product) : null;
}
export async function saveProduct(p: Product): Promise<void> {
  const now = Date.now();
  const data = { ...p, updatedAt: now, createdAt: p.createdAt || now };
  if (DEMO) {
    const list = lsGet<Product[]>(LS.products, []);
    const i = list.findIndex((x) => x.id === data.id);
    if (i >= 0) list[i] = data;
    else list.push(data);
    lsSet(LS.products, list);
    return;
  }
  await setDoc(doc(fdb(), 'products', data.id), stripUndefined(data), { merge: true });
}
export async function deleteProduct(id: string): Promise<void> {
  if (DEMO) {
    lsSet(LS.products, lsGet<Product[]>(LS.products, []).filter((p) => p.id !== id));
    return;
  }
  await deleteDoc(doc(fdb(), 'products', id));
}

// ---------- Settings ----------
export async function getSettings(): Promise<StoreSettings> {
  if (DEMO) return { ...demoSettings, ...lsGet<StoreSettings>(LS.settings, demoSettings) };
  const snap = await getDoc(doc(fdb(), 'settings', 'store'));
  // Gộp giá trị mặc định để các trường mới thêm sau (VD cloudName) luôn có mặt
  return snap.exists() ? { ...demoSettings, ...(snap.data() as StoreSettings) } : demoSettings;
}
export async function saveSettings(s: StoreSettings): Promise<void> {
  if (DEMO) {
    lsSet(LS.settings, s);
    return;
  }
  await setDoc(doc(fdb(), 'settings', 'store'), stripUndefined(s), { merge: true });
}

// ---------- Vouchers ----------
function calcDiscount(v: Voucher, subtotal: number): number {
  if (!v.active) return 0;
  if (v.expiresAt && Date.now() > v.expiresAt) return 0;
  if (v.minOrder && subtotal < v.minOrder) return 0;
  if (v.usageLimit != null && v.usedCount >= v.usageLimit) return 0;
  let d = v.type === 'percent' ? Math.round((subtotal * v.value) / 100) : v.value;
  if (v.maxDiscount != null) d = Math.min(d, v.maxDiscount);
  return Math.min(d, subtotal);
}
export async function applyVoucher(
  code: string,
  subtotal: number,
): Promise<{ voucher: Voucher; discount: number } | { error: string }> {
  const c = code.trim().toUpperCase();
  if (!c) return { error: 'Bạn chưa nhập mã voucher.' };
  let v: Voucher | undefined;
  if (DEMO) {
    v = lsGet<Voucher[]>(LS.vouchers, []).find((x) => x.code.toUpperCase() === c);
  } else {
    const q = query(collection(fdb(), 'vouchers'), where('code', '==', c));
    const snap = await getDocs(q);
    v = snap.docs.map((d) => d.data() as Voucher)[0];
  }
  if (!v) return { error: 'Mã voucher không tồn tại.' };
  if (!v.active) return { error: 'Mã voucher đã bị tắt.' };
  if (v.expiresAt && Date.now() > v.expiresAt) return { error: 'Mã voucher đã hết hạn.' };
  if (v.minOrder && subtotal < v.minOrder)
    return { error: `Đơn tối thiểu ${v.minOrder.toLocaleString('vi-VN')}đ để dùng mã này.` };
  if (v.usageLimit != null && v.usedCount >= v.usageLimit)
    return { error: 'Mã voucher đã hết lượt sử dụng.' };
  const discount = calcDiscount(v, subtotal);
  if (discount <= 0) return { error: 'Mã voucher không áp dụng được cho đơn này.' };
  return { voucher: v, discount };
}
export async function getAllVouchers(): Promise<Voucher[]> {
  if (DEMO) return lsGet<Voucher[]>(LS.vouchers, []);
  const snap = await getDocs(collection(fdb(), 'vouchers'));
  return snap.docs.map((d) => d.data() as Voucher);
}
export async function saveVoucher(v: Voucher): Promise<void> {
  const id = v.id || `v-${Date.now()}`;
  const data = { ...v, id };
  if (DEMO) {
    const list = lsGet<Voucher[]>(LS.vouchers, []);
    const i = list.findIndex((x) => x.id === id);
    if (i >= 0) list[i] = data;
    else list.push(data);
    lsSet(LS.vouchers, list);
    return;
  }
  await setDoc(doc(fdb(), 'vouchers', id), stripUndefined(data), { merge: true });
}
export async function deleteVoucher(id: string): Promise<void> {
  if (DEMO) {
    lsSet(LS.vouchers, lsGet<Voucher[]>(LS.vouchers, []).filter((v) => v.id !== id));
    return;
  }
  await deleteDoc(doc(fdb(), 'vouchers', id));
}

// ---------- Orders ----------
export interface CreateOrderInput {
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  note?: string;
  items: Order['items'];
  subtotal: number;
  discount: number;
  voucherCode?: string;
  total: number;
}

function nextCode(seq: number): string {
  return `BS${seq}`;
}

export async function createOrder(input: CreateOrderInput): Promise<Order> {
  const phone = normalizePhone(input.customerPhone);
  if (DEMO) {
    const seq = (lsGet<number>(LS.seq, ORDER_SEQ_START) + 1) as number;
    lsSet(LS.seq, seq);
    const code = nextCode(seq);
    const vouchers = lsGet<Voucher[]>(LS.vouchers, []);
    if (input.voucherCode) {
      const vi = vouchers.findIndex((x) => x.code.toUpperCase() === input.voucherCode!.toUpperCase());
      if (vi >= 0) {
        vouchers[vi] = { ...vouchers[vi], usedCount: vouchers[vi].usedCount + 1 };
        lsSet(LS.vouchers, vouchers);
      }
    }
    const order: Order = {
      id: code,
      code,
      customerName: input.customerName.trim(),
      customerPhone: phone,
      customerEmail: input.customerEmail.trim(),
      note: input.note?.trim(),
      items: input.items,
      subtotal: input.subtotal,
      discount: input.discount,
      voucherCode: input.voucherCode,
      total: input.total,
      status: 'pending',
      paymentMethod: 'bank',
      createdAt: Date.now(),
    };
    const orders = lsGet<Order[]>(LS.orders, []);
    orders.unshift(order);
    lsSet(LS.orders, orders);
    return order;
  }
  const database = fdb();
  const order = await runTransaction(database, async (tx) => {
    const counterRef = doc(database, 'counters', 'orders');
    const counterSnap = await tx.get(counterRef);
    const seq = (counterSnap.exists() ? (counterSnap.data().seq as number) : ORDER_SEQ_START) + 1;
    tx.set(counterRef, { seq }, { merge: true });
    const code = nextCode(seq);
    if (input.voucherCode) {
      const vq = query(
        collection(database, 'vouchers'),
        where('code', '==', input.voucherCode.toUpperCase()),
      );
      const vsnap = await getDocs(vq);
      const vdoc = vsnap.docs[0];
      if (vdoc) tx.update(vdoc.ref, { usedCount: (vdoc.data().usedCount as number) + 1 });
    }
    const data: Order = {
      id: code,
      code,
      customerName: input.customerName.trim(),
      customerPhone: phone,
      customerEmail: input.customerEmail.trim(),
      note: input.note?.trim(),
      items: input.items,
      subtotal: input.subtotal,
      discount: input.discount,
      voucherCode: input.voucherCode,
      total: input.total,
      status: 'pending',
      paymentMethod: 'bank',
      createdAt: Date.now(),
    };
    tx.set(doc(database, 'orders', code), { ...stripUndefined(data), createdAtServer: serverTimestamp() });
    return data;
  });
  return order;
}

/** Khách bấm "Tôi đã chuyển khoản": pending -> paid */
export async function markOrderPaid(code: string): Promise<void> {
  if (DEMO) {
    const orders = lsGet<Order[]>(LS.orders, []);
    const i = orders.findIndex((o) => o.code === code);
    if (i >= 0 && orders[i].status === 'pending') {
      orders[i] = { ...orders[i], status: 'paid', paidAt: Date.now() };
      lsSet(LS.orders, orders);
    }
    return;
  }
  const database = fdb();
  await runTransaction(database, async (tx) => {
    const ref = doc(database, 'orders', code);
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new Error('Không tìm thấy đơn hàng.');
    if ((snap.data().status as OrderStatus) !== 'pending') return;
    tx.update(ref, { status: 'paid', paidAt: Date.now() });
  });
}

export async function getOrder(code: string): Promise<Order | null> {
  const c = code.trim().toUpperCase();
  if (DEMO) return lsGet<Order[]>(LS.orders, []).find((o) => o.code === c) ?? null;
  const snap = await getDoc(doc(fdb(), 'orders', c));
  return snap.exists() ? (snap.data() as Order) : null;
}

export async function listOrders(status?: OrderStatus | 'all'): Promise<Order[]> {
  if (DEMO) {
    const all = lsGet<Order[]>(LS.orders, []);
    return status && status !== 'all' ? all.filter((o) => o.status === status) : all;
  }
  const database = fdb();
  // Lọc status ở client để không cần composite index trên Firestore.
  const q = query(collection(database, 'orders'), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  const all = snap.docs.map((d) => d.data() as Order);
  return status && status !== 'all' ? all.filter((o) => o.status === status) : all;
}

export async function setOrderStatus(code: string, status: OrderStatus): Promise<void> {
  const patch: Partial<Order> =
    status === 'confirmed'
      ? { status, confirmedAt: Date.now() }
      : status === 'paid'
        ? { status, paidAt: Date.now() }
        : { status };
  if (DEMO) {
    const orders = lsGet<Order[]>(LS.orders, []);
    const i = orders.findIndex((o) => o.code === code);
    if (i >= 0) {
      orders[i] = { ...orders[i], ...patch };
      lsSet(LS.orders, orders);
    }
    return;
  }
  await setDoc(doc(fdb(), 'orders', code), patch, { merge: true });
}

// ---------- Dashboard ----------
export interface RevenueStats {
  revenue: number; // tổng doanh thu đơn confirmed
  byStatus: Record<OrderStatus, number>;
  last7: { label: string; revenue: number; count: number }[];
  recent: Order[];
}
export async function getRevenueStats(): Promise<RevenueStats> {
  const orders = await listOrders('all');
  const byStatus: Record<OrderStatus, number> = { pending: 0, paid: 0, confirmed: 0, cancelled: 0 };
  let revenue = 0;
  for (const o of orders) {
    byStatus[o.status] = (byStatus[o.status] ?? 0) + 1;
    if (o.status === 'confirmed') revenue += o.total;
  }
  const days: { label: string; revenue: number; count: number }[] = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today.getTime() - i * 86400000);
    const next = d.getTime() + 86400000;
    const inDay = orders.filter(
      (o) => o.status === 'confirmed' && o.createdAt >= d.getTime() && o.createdAt < next,
    );
    days.push({
      label: `${d.getDate()}/${d.getMonth() + 1}`,
      revenue: inDay.reduce((s, o) => s + o.total, 0),
      count: inDay.length,
    });
  }
  return { revenue, byStatus, last7: days, recent: orders.slice(0, 8) };
}
