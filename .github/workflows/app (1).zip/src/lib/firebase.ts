import { initializeApp, type FirebaseApp } from 'firebase/app';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getAuth, type Auth } from 'firebase/auth';

// Đọc config từ biến môi trường VITE_*. Khi chưa cấu hình (VD: bản demo),
// isConfigured() trả về false và app chạy ở chế độ demo (dữ liệu mẫu local).
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string | undefined,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string | undefined,
};

export function isConfigured(): boolean {
  return Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
}

let _app: FirebaseApp | null = null;
let _db: Firestore | null = null;
let _auth: Auth | null = null;

function app(): FirebaseApp {
  if (!_app) _app = initializeApp(firebaseConfig);
  return _app;
}

/** Firestore - chỉ gọi khi isConfigured() === true */
export function db(): Firestore {
  if (!_db) _db = getFirestore(app());
  return _db;
}

/** Firebase Auth - chỉ gọi khi isConfigured() === true */
export function auth(): Auth {
  if (!_auth) _auth = getAuth(app());
  return _auth;
}
