import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { auth as getAuth, isConfigured } from './firebase';
import { getSettings } from './db';
import { demoSettings } from './demo-data';
import type { StoreSettings } from './types';

interface StoreCtx {
  settings: StoreSettings;
  user: User | null;
  isAdmin: boolean;
  loading: boolean;
  demo: boolean;
}

const Ctx = createContext<StoreCtx>({
  settings: demoSettings,
  user: null,
  isAdmin: false,
  loading: true,
  demo: true,
});

export function StoreProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<StoreSettings>(demoSettings);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const demo = !isConfigured();

  useEffect(() => {
    let alive = true;
    getSettings()
      .then((s) => alive && setSettings(s))
      .catch(() => {})
      .finally(() => alive && setLoading(false));
    if (demo) {
      // Chế độ demo: đăng nhập admin bằng bất kỳ email nào ở trang /admin/login
      try {
        const em = localStorage.getItem('beesystore_demo_admin');
        if (em) setUser({ email: em } as User);
      } catch {}
      return () => {
        alive = false;
      };
    }
    const unsub = onAuthStateChanged(getAuth(), (u) => {
      if (alive) setUser(u);
    });
    return () => {
      alive = false;
      unsub();
    };
  }, [demo]);

  const isAdmin = Boolean(
    user && (demo ? true : settings.adminUids?.includes(user.uid)),
  );

  return (
    <Ctx.Provider value={{ settings, user, isAdmin, loading, demo }}>{children}</Ctx.Provider>
  );
}

export function useStore() {
  return useContext(Ctx);
}
