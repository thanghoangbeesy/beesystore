// Tải ảnh lên Cloudinary (unsigned) sau khi nén phía trình duyệt.
// Dùng cấu hình cloudName + uploadPreset trong Cài đặt shop.
// Khi chưa cấu hình: uploadImage ném lỗi rõ ràng để giao diện báo cho admin.
import type { StoreSettings } from './types';

export function isUploadConfigured(s: StoreSettings): boolean {
  return Boolean(s.cloudName?.trim() && s.uploadPreset?.trim());
}

const MAX_EDGE = 1600;

/** Nén ảnh về tối đa 1600px, JPEG 0.85 (giữ nguyên GIF để không mất ảnh động) */
async function compressImage(file: File): Promise<Blob> {
  if (file.type === 'image/gif') return file;
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = reject;
      i.src = url;
    });
    const scale = Math.min(1, MAX_EDGE / Math.max(img.naturalWidth, img.naturalHeight));
    if (scale === 1 && file.size <= 900_000) return file;
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(img.naturalWidth * scale);
    canvas.height = Math.round(img.naturalHeight * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return file;
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, 'image/jpeg', 0.85),
    );
    return blob ?? file;
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Tải 1 ảnh lên Cloudinary, trả về URL https công khai */
export async function uploadImage(file: File, settings: StoreSettings): Promise<string> {
  if (!isUploadConfigured(settings)) {
    throw new Error(
      'Chưa cấu hình tải ảnh. Vào Quản trị > Cài đặt, mục "Tải ảnh lên (Cloudinary)" để điền Cloud name và Upload preset.',
    );
  }
  if (!file.type.startsWith('image/')) {
    throw new Error('File được chọn không phải là ảnh.');
  }
  const blob = await compressImage(file);
  const fd = new FormData();
  fd.append('file', blob, 'beesy-store.jpg');
  fd.append('upload_preset', settings.uploadPreset.trim());
  fd.append('folder', 'beesy-store');
  const res = await fetch(
    `https://api.cloudinary.com/v1_1/${settings.cloudName.trim()}/image/upload`,
    { method: 'POST', body: fd },
  );
  const data = (await res.json().catch(() => null)) as
    | { secure_url?: string; error?: { message?: string } }
    | null;
  if (!res.ok || !data?.secure_url) {
    throw new Error(data?.error?.message || `Tải ảnh thất bại (mã ${res.status}).`);
  }
  return data.secure_url;
}
