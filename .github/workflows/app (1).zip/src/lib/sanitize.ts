// Lọc HTML mô tả sản phẩm trước khi hiển thị (chỉ admin mới soạn được mô tả,
// nhưng vẫn lọc theo danh sách trắng cho an toàn).
// Mô tả cũ dạng văn bản thuần (không có thẻ HTML) được giữ nguyên cách hiển thị cũ.

export function isHtmlText(s: string): boolean {
  return /<[a-z][\s\S]*?>/i.test(s);
}

const ALLOWED_TAGS = new Set([
  'P', 'BR', 'B', 'STRONG', 'I', 'EM', 'U', 'S', 'STRIKE', 'SPAN', 'DIV',
  'H2', 'H3', 'H4', 'UL', 'OL', 'LI', 'A', 'IMG', 'BLOCKQUOTE',
]);
const DROP_WITH_CONTENT = new Set(['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'FORM', 'LINK', 'META']);
const ALLOWED_STYLE_PROPS = new Set([
  'color', 'background-color', 'font-size', 'font-family', 'text-align',
  'font-weight', 'font-style', 'text-decoration',
]);

function filterStyle(style: string): string {
  const kept: string[] = [];
  for (const decl of style.split(';')) {
    const [prop, ...rest] = decl.split(':');
    const name = prop?.trim().toLowerCase();
    const value = rest.join(':').trim();
    if (name && value && ALLOWED_STYLE_PROPS.has(name) && !/url\(|expression|javascript/i.test(value)) {
      kept.push(`${name}: ${value}`);
    }
  }
  return kept.join('; ');
}

function cleanElement(el: Element): void {
  // Xử lý con trước (sao chép danh sách vì sẽ sửa cây)
  for (const child of Array.from(el.children)) {
    cleanElement(child);
  }
  for (const node of Array.from(el.childNodes)) {
    if (node.nodeType !== Node.ELEMENT_NODE) continue;
    const child = node as Element;
    const tag = child.tagName;
    if (DROP_WITH_CONTENT.has(tag)) {
      child.remove();
      continue;
    }
    if (!ALLOWED_TAGS.has(tag)) {
      // Thẻ không cho phép: gỡ thẻ nhưng giữ nội dung bên trong
      const parent = child.parentNode;
      if (parent) {
        while (child.firstChild) parent.insertBefore(child.firstChild, child);
        child.remove();
      }
      continue;
    }
    // Lọc thuộc tính
    for (const attr of Array.from(child.attributes)) {
      const name = attr.name.toLowerCase();
      let keep = false;
      if (name === 'style') {
        const filtered = filterStyle(attr.value);
        if (filtered) {
          child.setAttribute('style', filtered);
          keep = true;
        }
      } else if (tag === 'A' && name === 'href') {
        keep = /^(https?:|mailto:)/i.test(attr.value.trim());
      } else if (tag === 'A' && (name === 'target' || name === 'rel')) {
        keep = true;
      } else if (tag === 'IMG' && name === 'src') {
        keep = /^(https?:|data:image\/)/i.test(attr.value.trim());
      } else if (tag === 'IMG' && name === 'alt') {
        keep = true;
      }
      if (!keep) child.removeAttribute(attr.name);
    }
    if (tag === 'A') {
      child.setAttribute('rel', 'noreferrer');
      child.setAttribute('target', '_blank');
    }
    if (tag === 'IMG') {
      child.setAttribute('loading', 'lazy');
    }
  }
}

/** Lọc HTML mô tả, trả về chuỗi HTML an toàn để hiển thị */
export function sanitizeHtml(html: string): string {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  cleanElement(doc.body);
  return doc.body.innerHTML;
}
