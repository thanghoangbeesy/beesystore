﻿# Beesy Store

Web bán app của shop: **Beesy POS** (webapp bán hàng), **Beesy Trọ** (quản lý nhà trọ trên Google Sheet),
**Beesy Class** (website lớp tiền tiểu học). Khách tự đặt mua + chuyển khoản VietQR trên web;
shop xác nhận thanh toán rồi gửi file code + hướng dẫn.

Stack: Vite + React + TypeScript + react-router-dom + Firebase (Firestore + Auth + Hosting).
Giao diện: tông xanh lá + cam, font Inter (sans-serif), mobile-first và có đầy đủ giao diện PC.

## Chạy thử không cần Firebase (chế độ demo)

Chưa cần tạo project Firebase - cứ `npm install` rồi `npm run dev`, web chạy ngay với dữ liệu mẫu
lưu trên trình duyệt (góc trái dưới có nhãn "Bản demo"). Đăng nhập trang `/admin/login` bằng
email/password bất kỳ để xem trang quản trị.

## Triển khai thật (làm 1 lần)

1. **Tạo project Firebase** (console.firebase.google.com) -> bật **Authentication** (Email/Password)
   và **Firestore Database**.
2. **Thêm Web app** trong Project settings -> copy 6 giá trị config.
3. **Deploy 100% trên điện thoại** theo `.github/workflows/deploy.yml`:
   tạo repo -> dán workflow -> upload `app.zip` (source) -> thêm secrets
   (`FIREBASE_SERVICE_ACCOUNT`, `FIREBASE_PROJECT_ID`, 6 biến `VITE_FIREBASE_*`) -> Run workflow.
4. **Seed dữ liệu mẫu**: copy `.env.example` thành `.env`, điền config -> `npm run seed`.
5. **Tạo tài khoản admin**: Authentication -> Users -> Add user (email + password),
   copy **UID** -> Firestore -> `settings/store` -> thêm UID vào mảng `adminUids`.
6. **Cài đặt shop** tại `/admin/cai-dat`: STK + mã BIN + chủ tài khoản ngân hàng
   (để hiện QR thanh toán), banner, hero. Link file giao hàng điền ở từng sản phẩm (`fileUrl`).
7. Đăng nhập quản trị tại `/admin/login`.

## TODO cần Hoàng chốt

- [ ] Giá chính thức **Beesy POS** (đang để tạm 1.490.000đ)
- [ ] Giá chính thức **Beesy Class** (đang để tạm 990.000đ) - Beesy Trọ đã chốt 469.000đ
- [ ] STK + mã BIN + chủ tài khoản ngân hàng nhận tiền (Cài đặt -> `/admin/cai-dat`)
- [ ] Link file giao hàng cho từng sản phẩm (`fileUrl` trong Quản lý sản phẩm)
- [ ] Ảnh chụp thật của 3 app (đang dùng placeholder gradient + icon)

## Cấu trúc

```
src/
  components/  Icon.tsx (lineal SVG) - Layout.tsx (header pill/footer/Zalo) -
               ProductCard.tsx - ProductThumb.tsx (placeholder) - BuyModal.tsx (checkout)
  pages/       Home.tsx - ProductDetail.tsx - Lookup.tsx (tra cứu đơn)
  pages/admin/ Login.tsx - AdminLayout.tsx - Dashboard.tsx - Products.tsx -
               Orders.tsx - Vouchers.tsx - SettingsPage.tsx
  lib/         db.ts (Firestore + demo localStorage) - store.tsx (settings/auth) -
               types.ts - format.ts - firebase.ts - demo-data.ts
scripts/seed.mjs   nạp 3 sản phẩm + settings + voucher mẫu + counters
firestore.rules    public đọc products/settings/vouchers(active); orders tạo/get hạn chế; admin full quyền
firebase.json      Hosting (dist + rewrite SPA) + Firestore rules
.github/workflows/deploy.yml  build -> deploy (nhận app.zip như các app khác của shop)
```

## Quy ước mã đơn

`BS` + 6 số, tăng dần không tái dùng (transaction trên `counters/orders`).
Trạng thái: `pending` (chờ thanh toán) -> `paid` (khách bấm "Tôi đã chuyển khoản") ->
`confirmed` (admin xác nhận -> hiện link tải file) / `cancelled`.
