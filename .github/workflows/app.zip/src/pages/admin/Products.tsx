// Trang quản lý Sản phẩm (CRUD sản phẩm số)
import { useEffect, useState } from 'react';
import { deleteProduct, getAllProducts, saveProduct } from '../../lib/db';
import type { Product } from '../../lib/types';
import { fmtVND, unsignVietnamese } from '../../lib/format';
import { Icon } from '../../components/Icon';

const PRODUCT_TYPES = ['Webapp', 'Google Sheet', 'Website', 'Template'];
const PRODUCT_TAGS = ['', 'BÁN CHẠY', 'MỚI', 'GIẢM GIÁ', 'MIỄN PHÍ'];

function blankProduct(): Product {
  return {
    id: '',
    name: '',
    type: 'Webapp',
    version: 'v1.0',
    price: 0,
    oldPrice: undefined,
    tag: '',
    shortDesc: '',
    description: '',
    features: [],
    thumbnail: '',
    gallery: [],
    fileUrl: '',
    fileName: '',
    active: true,
    featured: false,
    soldCount: 0,
    createdAt: 0,
    updatedAt: 0,
  };
}

interface FormState {
  name: string;
  type: string;
  version: string;
  price: string;
  oldPrice: string;
  tag: string;
  shortDesc: string;
  description: string;
  features: string;
  thumbnail: string;
  gallery: string;
  fileUrl: string;
  fileName: string;
  soldCount: string;
  active: boolean;
  featured: boolean;
}

function toForm(p: Product): FormState {
  return {
    name: p.name,
    type: p.type,
    version: p.version,
    price: String(p.price),
    oldPrice: p.oldPrice != null ? String(p.oldPrice) : '',
    tag: p.tag ?? '',
    shortDesc: p.shortDesc,
    description: p.description,
    features: p.features.join('\n'),
    thumbnail: p.thumbnail,
    gallery: p.gallery.join('\n'),
    fileUrl: p.fileUrl,
    fileName: p.fileName,
    soldCount: String(p.soldCount),
    active: p.active,
    featured: p.featured,
  };
}

function inputStyle(): React.CSSProperties {
  return { width: '100%', padding: '10px 12px', border: '1px solid #e0e6ea', borderRadius: 10 };
}

export default function Products() {
  const [list, setList] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState<FormState>(() => toForm(blankProduct()));
  const [formErr, setFormErr] = useState('');
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    setErr('');
    try {
      setList(await getAllProducts());
    } catch {
      setErr('Không tải được danh sách sản phẩm.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await getAllProducts();
        if (alive) setList(data);
      } catch {
        if (alive) setErr('Không tải được danh sách sản phẩm.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function openCreate() {
    setEditing(null);
    setForm(toForm(blankProduct()));
    setFormErr('');
    setShowModal(true);
  }

  function openEdit(p: Product) {
    setEditing(p);
    setForm(toForm(p));
    setFormErr('');
    setShowModal(true);
  }

  async function handleDelete(id: string, name: string) {
    if (!window.confirm(`Xóa sản phẩm "${name}"? Thao tác này không thể hoàn tác.`)) return;
    try {
      await deleteProduct(id);
      setList((l) => l.filter((p) => p.id !== id));
    } catch {
      alert('Xóa sản phẩm thất bại. Vui lòng thử lại.');
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setFormErr('');
    const name = form.name.trim();
    if (!name) {
      setFormErr('Vui lòng nhập tên sản phẩm.');
      return;
    }
    const price = Number(form.price);
    if (!Number.isFinite(price) || price < 0) {
      setFormErr('Giá bán không hợp lệ.');
      return;
    }
    const oldPrice = form.oldPrice.trim() === '' ? undefined : Number(form.oldPrice);
    if (oldPrice !== undefined && (!Number.isFinite(oldPrice) || oldPrice < 0)) {
      setFormErr('Giá gốc không hợp lệ.');
      return;
    }
    const soldCount = Number(form.soldCount);
    if (!Number.isFinite(soldCount) || soldCount < 0) {
      setFormErr('Số lượt bán không hợp lệ.');
      return;
    }

    const id = editing?.id
      || unsignVietnamese(name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    if (!id) {
      setFormErr('Không tạo được mã sản phẩm từ tên. Hãy dùng tên có ký tự latin.');
      return;
    }

    setSaving(true);
    try {
      const p: Product = {
        ...(editing ?? blankProduct()),
        id,
        name,
        type: form.type,
        version: form.version.trim() || 'v1.0',
        price,
        oldPrice,
        tag: form.tag || undefined,
        shortDesc: form.shortDesc.trim(),
        description: form.description.trim(),
        features: form.features.split('\n').map((s) => s.trim()).filter(Boolean),
        thumbnail: form.thumbnail.trim(),
        gallery: form.gallery.split('\n').map((s) => s.trim()).filter(Boolean),
        fileUrl: form.fileUrl.trim(),
        fileName: form.fileName.trim(),
        soldCount: Math.floor(soldCount),
        active: form.active,
        featured: form.featured,
      };
      await saveProduct(p);
      setShowModal(false);
      await load();
    } catch {
      setFormErr('Lưu sản phẩm thất bại. Vui lòng thử lại.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div style={{ marginBottom: 16 }}>
        <button className="btn btn-green" onClick={openCreate}>
          <Icon name="plus" size={18} /> Thêm sản phẩm
        </button>
      </div>

      {err && <p className="f-err">{err}</p>}
      {loading ? (
        <p>Đang tải...</p>
      ) : list.length === 0 ? (
        <p className="empty">Chưa có sản phẩm nào. Nhấn "Thêm sản phẩm" để tạo mới.</p>
      ) : (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>Tên sản phẩm</th>
                <th>Giá</th>
                <th>Đã bán</th>
                <th>Trạng thái</th>
                <th>Nổi bật</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((p) => (
                <tr key={p.id}>
                  <td>
                    <b>{p.name}</b>
                    <div style={{ fontSize: 12.5, color: '#6b7684' }}>
                      {p.version} - {p.type}
                    </div>
                  </td>
                  <td>
                    {fmtVND(p.price)}
                    {p.oldPrice != null && p.oldPrice > p.price && (
                      <div style={{ fontSize: 12.5, color: '#6b7684', textDecoration: 'line-through' }}>
                        {fmtVND(p.oldPrice)}
                      </div>
                    )}
                  </td>
                  <td>{p.soldCount}</td>
                  <td>
                    <span className={'status-pill ' + (p.active ? 'confirmed' : 'cancelled')}>
                      {p.active ? 'Đang bán' : 'Ẩn'}
                    </span>
                  </td>
                  <td>{p.featured ? <Icon name="check" size={18} /> : ''}</td>
                  <td>
                    <div className="row-actions">
                      <button className="mini-btn" onClick={() => openEdit(p)} title="Sửa">
                        <Icon name="edit" size={16} /> Sửa
                      </button>
                      <button className="mini-btn red" onClick={() => handleDelete(p.id, p.name)} title="Xóa">
                        <Icon name="trash" size={16} /> Xóa
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 640 }}>
            <div className="modal-head">
              <h3>{editing ? 'Sửa sản phẩm' : 'Thêm sản phẩm'}</h3>
              <button className="icon-btn" onClick={() => setShowModal(false)} aria-label="Đóng">
                <Icon name="x" size={20} />
              </button>
            </div>
            <div className="modal-body">
              <form onSubmit={handleSave} className="form-grid">
                <div>
                  <label className="f-label">Tên sản phẩm *</label>
                  <input value={form.name} onChange={(e) => set('name', e.target.value)} style={inputStyle()} placeholder="VD: Beesy Trọ" />
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <div>
                    <label className="f-label">Loại</label>
                    <select value={form.type} onChange={(e) => set('type', e.target.value)} style={inputStyle()}>
                      {PRODUCT_TYPES.map((t) => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="f-label">Phiên bản</label>
                    <input value={form.version} onChange={(e) => set('version', e.target.value)} style={inputStyle()} placeholder="v1.0" />
                  </div>
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <div>
                    <label className="f-label">Giá bán (đ) *</label>
                    <input type="number" min={0} value={form.price} onChange={(e) => set('price', e.target.value)} style={inputStyle()} />
                  </div>
                  <div>
                    <label className="f-label">Giá gốc (đ)</label>
                    <input type="number" min={0} value={form.oldPrice} onChange={(e) => set('oldPrice', e.target.value)} style={inputStyle()} placeholder="Để trống nếu không giảm giá" />
                  </div>
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <div>
                    <label className="f-label">Nhãn nổi bật</label>
                    <select value={form.tag} onChange={(e) => set('tag', e.target.value)} style={inputStyle()}>
                      {PRODUCT_TAGS.map((t) => (
                        <option key={t} value={t}>{t === '' ? '(Không có)' : t}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="f-label">Đã bán</label>
                    <input type="number" min={0} value={form.soldCount} onChange={(e) => set('soldCount', e.target.value)} style={inputStyle()} />
                  </div>
                </div>
                <div>
                  <label className="f-label">Mô tả ngắn</label>
                  <input value={form.shortDesc} onChange={(e) => set('shortDesc', e.target.value)} style={inputStyle()} placeholder="Một câu giới thiệu trên thẻ sản phẩm" />
                </div>
                <div>
                  <label className="f-label">Mô tả chi tiết</label>
                  <textarea rows={4} value={form.description} onChange={(e) => set('description', e.target.value)} style={inputStyle()} />
                </div>
                <div>
                  <label className="f-label">Tính năng nổi bật</label>
                  <textarea rows={4} value={form.features} onChange={(e) => set('features', e.target.value)} style={inputStyle()} placeholder="Mỗi dòng một tính năng" />
                  <p className="f-hint">Mỗi dòng một tính năng.</p>
                </div>
                <div>
                  <label className="f-label">Ảnh đại diện (URL)</label>
                  <input value={form.thumbnail} onChange={(e) => set('thumbnail', e.target.value)} style={inputStyle()} placeholder="https://..." />
                </div>
                <div>
                  <label className="f-label">Ảnh minh họa thêm</label>
                  <textarea rows={3} value={form.gallery} onChange={(e) => set('gallery', e.target.value)} style={inputStyle()} placeholder="Mỗi dòng một URL ảnh" />
                  <p className="f-hint">Mỗi dòng một URL ảnh.</p>
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <div>
                    <label className="f-label">Link file giao hàng</label>
                    <input value={form.fileUrl} onChange={(e) => set('fileUrl', e.target.value)} style={inputStyle()} placeholder="Link Drive / file zip" />
                  </div>
                  <div>
                    <label className="f-label">Tên file hiển thị</label>
                    <input value={form.fileName} onChange={(e) => set('fileName', e.target.value)} style={inputStyle()} placeholder="VD: beesy-tro-v2.7.zip" />
                  </div>
                </div>
                <div className="form-grid two" style={{ gridTemplateColumns: '1fr 1fr' }}>
                  <label className="check-row">
                    <input type="checkbox" checked={form.active} onChange={(e) => set('active', e.target.checked)} />
                    Đang bán
                  </label>
                  <label className="check-row">
                    <input type="checkbox" checked={form.featured} onChange={(e) => set('featured', e.target.checked)} />
                    Nổi bật
                  </label>
                </div>
                {formErr && <p className="f-err">{formErr}</p>}
                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                  <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>
                    Hủy
                  </button>
                  <button type="submit" className="btn btn-green" disabled={saving}>
                    {saving ? 'Đang lưu...' : 'Lưu sản phẩm'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
