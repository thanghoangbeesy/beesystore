import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getActiveProducts, getProduct } from '../lib/db';
import { useStore } from '../lib/store';
import type { Product } from '../lib/types';
import { fmtVND, getVersions, hasMultipleVersions } from '../lib/format';
import { ProductThumb } from '../components/ProductThumb';
import { ProductCard } from '../components/ProductCard';
import { BuyModal } from '../components/BuyModal';
import { Icon } from '../components/Icon';

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const { settings } = useStore();
  const [product, setProduct] = useState<Product | null>(null);
  const [others, setOthers] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState(false);
  const [imgIdx, setImgIdx] = useState(0);
  const [verIdx, setVerIdx] = useState(0);

  useEffect(() => {
    setLoading(true);
    Promise.all([id ? getProduct(id) : Promise.resolve(null), getActiveProducts()])
      .then(([p, all]) => {
        setProduct(p && p.active ? p : null);
        setOthers(all.filter((x) => x.id !== id).slice(0, 4));
      })
      .catch(() => setProduct(null))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading)
    return (
      <div className="wrap">
        <div className="empty">
          <Icon name="refresh" size={40} />
          <p>Đang tải...</p>
        </div>
      </div>
    );
  if (!product)
    return (
      <div className="wrap">
        <div className="empty">
          <Icon name="alert" size={40} />
          <p>Không tìm thấy sản phẩm.</p>
          <div style={{ height: 12 }} />
          <Link className="btn btn-green" to="/">Về trang chủ</Link>
        </div>
      </div>
    );

  const gallery = [product.thumbnail, ...product.gallery].filter(Boolean);
  const zaloNum = settings.zalo.replace(/\s/g, '');
  const versions = getVersions(product);
  const selVer = versions[Math.min(verIdx, versions.length - 1)];
  const multiVer = hasMultipleVersions(product);

  return (
    <div className="wrap">
      <div className="detail-grid">
        <div>
          <div className="gallery-main">
            <ProductThumb type={product.type} thumbnail={gallery[imgIdx]} size={110} />
          </div>
          {gallery.length > 1 && (
            <div className="gallery-thumbs">
              {gallery.map((g, i) => (
                <button
                  key={i}
                  className={`g-thumb${i === imgIdx ? ' active' : ''}`}
                  onClick={() => setImgIdx(i)}
                >
                  <ProductThumb type={product.type} thumbnail={g} size={28} />
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="d-info">
          <span className="p-type">{product.type}</span>
          <h1>
            {product.name} <span style={{ color: 'var(--muted)', fontSize: '.65em' }}>{selVer.name}</span>
          </h1>
          <div className="d-meta">
            {product.tag && <span className="status-pill confirmed">{product.tag}</span>}
            {product.soldCount > 0 && <span>Đã bán {product.soldCount} lượt</span>}
          </div>
          <p style={{ color: 'var(--muted)', marginBottom: 6 }}>{product.shortDesc}</p>
          {multiVer && (
            <div className="ver-picker">
              <div className="ver-picker-label">Chọn phiên bản:</div>
              {versions.map((v, i) => (
                <button
                  key={i}
                  type="button"
                  className={`ver-opt${i === verIdx ? ' active' : ''}`}
                  onClick={() => setVerIdx(i)}
                >
                  <span className="ver-opt-main">
                    <span className="ver-opt-name">{v.name}</span>
                    {v.note && <span className="ver-opt-note">{v.note}</span>}
                  </span>
                  <span className="ver-opt-price">
                    {v.oldPrice != null && v.oldPrice > v.price && (
                      <span className="ver-opt-old">{fmtVND(v.oldPrice)}</span>
                    )}
                    {v.price === 0 ? 'Miễn phí' : fmtVND(v.price)}
                  </span>
                </button>
              ))}
            </div>
          )}
          <div className="d-price-box">
            <div className="d-price">
              {selVer.price === 0 ? 'Miễn phí' : fmtVND(selVer.price)}
              {selVer.oldPrice != null && selVer.oldPrice > selVer.price && (
                <span className="d-old">{fmtVND(selVer.oldPrice)}</span>
              )}
            </div>
            <div className="d-price-note">
              Thanh toán một lần - dùng vĩnh viễn, không phí duy trì hằng tháng.
            </div>
          </div>
          <div className="d-cta">
            <button className="btn btn-orange" onClick={() => setBuying(true)}>
              <Icon name="bag" size={18} /> Mua ngay
            </button>
            <a
              className="btn btn-outline"
              href={`https://zalo.me/${zaloNum}?text=${encodeURIComponent(`Chào shop, mình muốn hỏi về ${product.name} ${selVer.name}`)}`}
              target="_blank"
              rel="noreferrer"
            >
              <Icon name="chat" size={18} /> Hỏi qua Zalo
            </a>
          </div>
          <div className="d-trust">
            <div className="t-row">
              <Icon name="check" size={17} />
              <span><b>Nhận đủ file</b> mã nguồn + hướng dẫn cài đặt chi tiết sau khi shop xác nhận.</span>
            </div>
            <div className="t-row">
              <Icon name="check" size={17} />
              <span><b>Hỗ trợ tận tay</b> bởi chính người làm ra sản phẩm qua Zalo {settings.zalo}.</span>
            </div>
            <div className="t-row">
              <Icon name="check" size={17} />
              <span><b>Thanh toán an toàn</b> bằng chuyển khoản VietQR, nội dung ghi rõ mã đơn.</span>
            </div>
          </div>
        </div>
      </div>

      <div className="detail-body">
        <div className="d-desc">
          <h2 style={{ fontSize: 20, marginBottom: 12 }}>Mô tả sản phẩm</h2>
          {product.description.split('\n').map((para, i) => (
            <p key={i}>{para}</p>
          ))}
          <h2 style={{ fontSize: 20, margin: '22px 0 4px' }}>Tính năng nổi bật</h2>
          <ul className="feat-list">
            {product.features.map((f, i) => (
              <li key={i}>
                <Icon name="check" size={17} />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <div className="side-card">
            <h3>Thông tin phiên bản</h3>
            {versions.map((v, i) => (
              <div
                className="ver-link"
                key={i}
                onClick={() => setVerIdx(i)}
                style={multiVer ? { cursor: 'pointer' } : undefined}
              >
                <span>
                  {v.name}
                  {i === verIdx && multiVer ? ' (đang chọn)' : ''}
                </span>
                <b>{v.price === 0 ? 'Miễn phí' : fmtVND(v.price)}</b>
              </div>
            ))}
            <div className="ver-link">
              <span>Loại sản phẩm</span>
              <b>{product.type}</b>
            </div>
            <div className="ver-link">
              <span>Hình thức</span>
              <b>Mua đứt 1 lần</b>
            </div>
            <div className="ver-link">
              <span>Tên file giao</span>
              <b style={{ fontSize: 13 }}>{selVer.fileName}</b>
            </div>
          </div>
        </div>
      </div>

      {others.length > 0 && (
        <section className="section" style={{ paddingTop: 8 }}>
          <div className="section-head">
            <h2>Sản phẩm tương tự</h2>
            <Link className="more" to="/">
              Xem tất cả <Icon name="chevR" size={15} />
            </Link>
          </div>
          <div className="product-grid">
            {others.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {buying && <BuyModal product={product} version={selVer} onClose={() => setBuying(false)} />}
    </div>
  );
}
