import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getOrder, getProduct } from '../lib/db';
import { useStore } from '../lib/store';
import type { Order, OrderStatus } from '../lib/types';
import { fmtVND, normalizePhone, timeAgo } from '../lib/format';
import { Icon } from '../components/Icon';

const statusLabel: Record<OrderStatus, string> = {
  pending: 'Chờ thanh toán',
  paid: 'Đã thanh toán - chờ shop xác nhận',
  confirmed: 'Đã xác nhận - đã giao file',
  cancelled: 'Đã hủy',
};

const steps: { key: string; label: string }[] = [
  { key: 'created', label: 'Đã đặt hàng' },
  { key: 'paid', label: 'Đã thanh toán' },
  { key: 'confirmed', label: 'Đã giao file' },
];

function stepIndex(o: Order): number {
  if (o.status === 'cancelled') return -1;
  if (o.status === 'confirmed') return 3;
  if (o.status === 'paid') return 2;
  return 1;
}

export function Lookup() {
  const { settings } = useStore();
  const [params] = useSearchParams();
  const [code, setCode] = useState(params.get('code') || '');
  const [phone, setPhone] = useState('');
  const [order, setOrder] = useState<Order | null>(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [lookedUp, setLookedUp] = useState(false);

  useEffect(() => {
    if (params.get('code')) setCode(params.get('code')!);
  }, [params]);

  const doLookup = async () => {
    setErr('');
    setOrder(null);
    if (!code.trim()) return setErr('Bạn nhập mã đơn hàng nhé. VD: BS100001.');
    if (!phone.trim()) return setErr('Bạn nhập số điện thoại đã dùng khi đặt hàng.');
    setBusy(true);
    try {
      const o = await getOrder(code);
      if (!o || normalizePhone(o.customerPhone) !== normalizePhone(phone)) {
        setErr('Không tìm thấy đơn hàng với mã và số điện thoại này.');
      } else {
        setOrder(o);
      }
    } catch {
      setErr('Có lỗi xảy ra, bạn thử lại nhé.');
    } finally {
      setBusy(false);
      setLookedUp(true);
    }
  };

  const idx = order ? stepIndex(order) : 0;

  return (
    <div className="wrap">
      <div className="lookup-card">
        <h2 style={{ fontSize: 21, textAlign: 'center' }}>Tra cứu đơn hàng</h2>
        <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 14, margin: '6px 0 18px' }}>
          Nhập mã đơn và số điện thoại bạn đã dùng khi đặt hàng.
        </p>
        <label className="f-label">Mã đơn hàng</label>
        <input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="BS100001"
          style={{ textTransform: 'uppercase' }}
        />
        <div style={{ height: 12 }} />
        <label className="f-label">Số điện thoại</label>
        <input
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="09xxxxxxxx"
          inputMode="tel"
        />
        {err && <div className="f-err">{err}</div>}
        <div style={{ height: 16 }} />
        <button className="btn btn-green btn-block" onClick={doLookup} disabled={busy}>
          <Icon name="search" size={17} /> {busy ? 'Đang tra cứu...' : 'Tra cứu'}
        </button>

        {lookedUp && order && (
          <div style={{ marginTop: 22 }}>
            {order.status === 'cancelled' ? (
              <div className="empty">
                <Icon name="x" size={36} />
                <p>
                  Đơn <b>{order.code}</b> đã bị hủy.
                </p>
              </div>
            ) : (
              <>
                <div className="status-steps">
                  {steps.map((s, i) => (
                    <div key={s.key} className={`st${idx > i ? ' done' : ''}`}>
                      <span className="dot">
                        {idx > i ? <Icon name="check" size={16} /> : <span>{i + 1}</span>}
                      </span>
                      <br />
                      {s.label}
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 12 }}>
                  <span className={`status-pill ${order.status}`}>{statusLabel[order.status]}</span>
                </div>
                <div className="order-line">
                  <span>Mã đơn</span>
                  <b>{order.code}</b>
                </div>
                {order.items.map((it, i) => (
                  <div className="order-line" key={i}>
                    <span>
                      {it.productName} ({it.version})
                    </span>
                    <span>{fmtVND(it.price)}</span>
                  </div>
                ))}
                {order.discount > 0 && (
                  <div className="order-line">
                    <span>Voucher {order.voucherCode}</span>
                    <span className="disc">-{fmtVND(order.discount)}</span>
                  </div>
                )}
                <div className="order-line total">
                  <span>Tổng thanh toán</span>
                  <b>{fmtVND(order.total)}</b>
                </div>
                <div className="f-hint">Đặt lúc: {timeAgo(order.createdAt)}</div>
                {order.status === 'confirmed' && (
                  <div className="panel" style={{ marginTop: 16 }}>
                    <h3>File của bạn đã sẵn sàng</h3>
                    {order.items[0] && (
                      <p style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 12 }}>
                        Nếu nút tải không mở được, bạn nhắn Zalo {settings.zalo} kèm mã đơn{' '}
                        <b>{order.code}</b> để shop gửi lại file nhé.
                      </p>
                    )}
                    <DownloadButton order={order} />
                  </div>
                )}
                {order.status === 'pending' && (
                  <p style={{ fontSize: 14, color: 'var(--muted)', marginTop: 12 }}>
                    Đơn đang chờ thanh toán. Bạn nhắn Zalo {settings.zalo} kèm mã đơn{' '}
                    <b>{order.code}</b> để được hướng dẫn nhé.
                  </p>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function DownloadButton({ order }: { order: Order }) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    // Lấy fileUrl từ sản phẩm trong đơn (đơn demo có thể chưa có link)
    getProduct(order.items[0]?.productId || '').then((p) => {
      if (p?.fileUrl) setUrl(p.fileUrl);
    });
  }, [order]);
  if (!url)
    return (
      <p style={{ fontSize: 14 }}>
        Shop sẽ gửi link tải file qua Zalo/Email cho bạn trong thời gian sớm nhất.
      </p>
    );
  return (
    <a className="btn btn-green btn-block" href={url} target="_blank" rel="noreferrer">
      <Icon name="download" size={18} /> Tải file sản phẩm
    </a>
  );
}
