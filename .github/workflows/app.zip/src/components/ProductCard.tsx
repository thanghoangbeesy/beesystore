import { useNavigate } from 'react-router-dom';
import type { Product } from '../lib/types';
import { fmtVND } from '../lib/format';
import { ProductThumb } from './ProductThumb';

export function ProductCard({ product }: { product: Product }) {
  const navigate = useNavigate();
  return (
    <article className="p-card" onClick={() => navigate(`/san-pham/${product.id}`)}>
      <div className="p-thumb">
        {product.tag && (
          <span className={`p-badge${product.tag === 'MỚI' ? ' green' : ''}`}>{product.tag}</span>
        )}
        <ProductThumb type={product.type} thumbnail={product.thumbnail} size={56} />
      </div>
      <div className="p-body">
        <span className="p-type">{product.type}</span>
        <div className="p-name">
          {product.name} <span className="ver">({product.version})</span>
        </div>
        <div className="p-desc">{product.shortDesc}</div>
        <div className="p-price-row">
          <span className="p-price">{fmtVND(product.price)}</span>
          {product.oldPrice ? <span className="p-old">{fmtVND(product.oldPrice)}</span> : null}
        </div>
        {product.soldCount > 0 && <div className="p-sold">Đã bán {product.soldCount} lượt</div>}
      </div>
    </article>
  );
}
