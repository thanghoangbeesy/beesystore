// Modal mua hàng: form thông tin -> thanh toán VietQR -> thành công.
// Không giỏ hàng, mua trực tiếp, không cần đăng nhập.
import { useState } from 'react';
import { Link } from 'react-router-dom';
import type { Order, Product, Voucher } from '../lib/types';
import { useStore } from '../lib/store';
import { applyVoucher, createOrder, markOrderPaid } from '../lib/db';
import {
  fmtVND,
  isValidEmail,
  isValidVNPhone,
  normalizePhone,
  buildVietQRUrl,
  bankNameFromBin,
} from '../lib/format';
import { Icon } from './Icon';

type Step = 'form' | 'pay' | 'done';

export function BuyModal({ product, onClose }: { product: Product; onClose: () => void }) {
  const { settings } = useStore();
  const [step, setStep] = useState<Step>('form');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [note, setNote] = useState('');
  const [voucherCode, setVoucherCode] = useState('');
  const [voucher, setVoucher] = useState<Voucher | null>(null);
  const [discount, setDiscount] = useState(0);
  const [voucherMsg, setVoucherMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [order, setOrder] = useState<Order | null>(null);
  const [copied, setCopied] = useState('');

  const subtotal = product.price;
  const total = Math.max(0, subtotal - discount);
  const bankReady = Boolean(settings.bankBin && settings.bankAccount);

  const doApplyVoucher = async () => {
    setVoucherMsg('');
    const r = await applyVoucher(voucherCode, subtotal);
    if ('error' in r) {
      setVoucher(null);
      setDiscount(0);
      setVoucherMsg(r.error);
    } else {
      setVoucher(r.voucher);
      setDiscount(r.discount);
      setVoucherMsg(`Đã áp dụng: giảm ${fmtVND(r.discount)}`);
    }
  };

  const submitForm = async () => {
    setErr('');
    if (name.trim().length < 2) return setErr('Bạn vui lòng nhập họ tên.');
    if (!isValidVNPhone(phone)) return setErr('Số điện thoại (Zalo) chưa đúng. VD: 0943571886.');
    if (!isValidEmail(email)) return setErr('Email chưa đúng định dạng.');
    setBusy(true);
    try {
      const o = await createOrder({
        customerName: name,
        customerPhone: phone,
        customerEmail: email,
        note,
        items: [
          {
            productId: product.id,
            productName: product.name,
            version: product.version,
            price: product.price,
            qty: 1,
          },
        ],
        subtotal,
        discount,
        voucherCode: voucher?.code,
        total,
      });
      setOrder(o);
      setStep('pay');
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Không tạo được đơn hàng, bạn thử lại nhé.');
    } finally {
      setBusy(false);
    }
  };

  const confirmPaid = async () => {
    if (!order) return;
    setBusy(true);
    try {
      await markOrderPaid(order.code);
      setStep('done');
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Có lỗi, bạn thử lại nhé.');
    } finally {
      setBusy(false);
    }
  };

  const copy = (label: string, text: string) => {
    navigator.clipboard?.writeText(text).then(
      () => {
        setCopied(label);
        setTimeout(() => setCopied(''), 1500);
      },
      () => {},
    );
  };

  const qrUrl =
    order && bankReady
      ? buildVietQRUrl(
          settings.bankBin,
          settings.bankAccount,
          settings.bankAccountName || settings.shopName,
          order.total,
          order.code,
        )
      : '';

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <div className="modal-head">
          <h3>{step === 'done' ? 'Đặt hàng thành công' : `Mua ${product.name}`}</h3>
          <button className="icon-btn" onClick={onClose} aria-label="Đóng">
            <Icon name="x" size={18} />
          </button>
        </div>
        <div className="modal-body">
          <div className="steps">
            <div className="s done" />
            <div className={`s${step === 'pay' || step === 'done' ? ' done' : ''}`} />
            <div className={`s${step === 'done' ? ' done' : ''}`} />
          </div>

          {step === 'form' && (
            <>
              <div className="order-line">
                <span>
                  {product.name} <b>({product.version})</b> × 1
                </span>
                <span>{fmtVND(subtotal)}</span>
              </div>
              <div style={{ height: 12 }} />
              <label className="f-label">Họ tên *</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nguyễn Văn A" />
              <div style={{ height: 12 }} />
              <label className="f-label">Số điện thoại (Zalo) *</label>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="09xxxxxxxx"
                inputMode="tel"
              />
              <div className="f-hint">Shop liên hệ và gửi file qua Zalo theo số này.</div>
              <div style={{ height: 12 }} />
              <label className="f-label">Email *</label>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ban@email.com"
                inputMode="email"
              />
              <div style={{ height: 12 }} />
              <label className="f-label">Mã voucher</label>
              {voucher ? (
                <div className="voucher-ok">
                  <Icon name="ticket" size={17} />
                  {voucher.code} - giảm {fmtVND(discount)}
                  <button
                    onClick={() => {
                      setVoucher(null);
                      setDiscount(0);
                      setVoucherCode('');
                      setVoucherMsg('');
                    }}
                  >
                    Xóa
                  </button>
                </div>
              ) : (
                <>
                  <div className="voucher-row">
                    <input
                      value={voucherCode}
                      onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                      placeholder="Nhập mã nếu có"
                    />
                    <button className="btn btn-outline btn-sm" onClick={doApplyVoucher} type="button">
                      Áp dụng
                    </button>
                  </div>
                  {voucherMsg && (
                    <div className={voucher ? 'f-hint' : 'f-err'} style={voucher ? { color: 'var(--green-deep)', fontWeight: 700 } : undefined}>
                      {voucherMsg}
                    </div>
                  )}
                </>
              )}
              <div style={{ height: 12 }} />
              <label className="f-label">Ghi chú (không bắt buộc)</label>
              <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="VD: cần hỗ trợ cài đặt buổi tối" />
              <div className="order-line total">
                <span>Tổng thanh toán</span>
                <b>{fmtVND(total)}</b>
              </div>
              {discount > 0 && (
                <div className="order-line">
                  <span>Đã giảm voucher</span>
                  <span className="disc">-{fmtVND(discount)}</span>
                </div>
              )}
              {err && <div className="f-err">{err}</div>}
              <div style={{ height: 16 }} />
              <button className="btn btn-green btn-block" onClick={submitForm} disabled={busy}>
                {busy ? 'Đang tạo đơn...' : 'Tiếp tục thanh toán'}
              </button>
            </>
          )}

          {step === 'pay' && order && (
            <>
              <div className="order-line">
                <span>Mã đơn hàng</span>
                <b>{order.code}</b>
              </div>
              <div className="order-line total">
                <span>Số tiền cần chuyển</span>
                <b>{fmtVND(order.total)}</b>
              </div>
              {bankReady ? (
                <div className="qr-box">
                  <img src={qrUrl} alt="QR chuyển khoản" />
                  <div className="f-hint">Quét mã bằng app ngân hàng - nội dung chuyển khoản đã điền sẵn mã đơn.</div>
                  <div className="bank-info">
                    <div className="row">
                      <span>Ngân hàng</span>
                      <b>{bankNameFromBin(settings.bankBin) || settings.bankBin}</b>
                    </div>
                    <div className="row">
                      <span>Số tài khoản</span>
                      <b>{settings.bankAccount}</b>
                    </div>
                    <div className="row">
                      <span>Chủ tài khoản</span>
                      <b>{settings.bankAccountName || settings.shopName}</b>
                    </div>
                    <div className="row">
                      <span>Nội dung</span>
                      <b>{order.code}</b>
                    </div>
                    <div className="row">
                      <button className="mini-copy" onClick={() => copy('stk', settings.bankAccount)}>
                        <Icon name="copy" size={14} /> {copied === 'stk' ? 'Đã chép STK' : 'Chép STK'}
                      </button>
                      <button className="mini-copy" onClick={() => copy('nd', order.code)}>
                        <Icon name="copy" size={14} /> {copied === 'nd' ? 'Đã chép' : 'Chép nội dung'}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="panel" style={{ margin: '14px 0' }}>
                  <h3>Thanh toán qua Zalo</h3>
                  <p style={{ fontSize: 14, color: 'var(--muted)' }}>
                    Shop đang cập nhật thông tin chuyển khoản. Bạn nhắn Zalo{' '}
                    <b>{settings.zalo}</b> kèm mã đơn <b>{order.code}</b> để được hướng dẫn thanh toán nhé.
                  </p>
                  <div style={{ height: 10 }} />
                  <a
                    className="btn btn-green btn-block"
                    href={`https://zalo.me/${settings.zalo.replace(/\s/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Icon name="chat" size={18} /> Nhắn Zalo shop
                  </a>
                </div>
              )}
              {err && <div className="f-err">{err}</div>}
              <div style={{ height: 8 }} />
              <button className="btn btn-orange btn-block" onClick={confirmPaid} disabled={busy}>
                <Icon name="check" size={18} /> {busy ? 'Đang xử lý...' : 'Tôi đã chuyển khoản'}
              </button>
              <div className="f-hint" style={{ textAlign: 'center', marginTop: 10 }}>
                Chỉ bấm sau khi bạn đã chuyển khoản thành công. Shop xác nhận rồi gửi file cho bạn.
              </div>
            </>
          )}

          {step === 'done' && order && (
            <div className="success-hero">
              <div className="ok-ring">
                <Icon name="check" size={38} strokeWidth={2.4} />
              </div>
              <h3>Đã ghi nhận thanh toán!</h3>
              <p style={{ color: 'var(--muted)', fontSize: 14.5, marginTop: 8 }}>
                Shop sẽ kiểm tra và gửi file + hướng dẫn qua Zalo/Email cho bạn trong thời gian sớm nhất.
              </p>
              <div className="order-code-big">
                {order.code}
                <button className="mini-copy" onClick={() => copy('code', order.code)}>
                  <Icon name="copy" size={14} /> {copied === 'code' ? 'Đã chép' : 'Chép mã'}
                </button>
              </div>
              <p style={{ fontSize: 13.5, color: 'var(--muted)' }}>
                SĐT đặt hàng: <b>{normalizePhone(order.customerPhone)}</b> - dùng để tra cứu đơn hàng.
              </p>
              <div style={{ height: 16 }} />
              <Link className="btn btn-green btn-block" to={`/tra-cuu?code=${order.code}`} onClick={onClose}>
                <Icon name="search" size={17} /> Tra cứu đơn hàng
              </Link>
              <div style={{ height: 10 }} />
              <button className="btn btn-ghost btn-block" onClick={onClose}>
                Về trang chủ
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
