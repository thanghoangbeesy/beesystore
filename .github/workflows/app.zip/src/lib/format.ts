// Định dạng tiền tệ, chuỗi tiếng Việt, mã đơn - dùng chung

export function fmtVND(n: number): string {
  return new Intl.NumberFormat('vi-VN').format(Math.round(n)) + 'đ';
}

export function unsignVietnamese(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

/** Mã đơn hàng: BS + 6 chữ số, VD: BS650031 */
export function genOrderCode(): string {
  const n = Math.floor(100000 + Math.random() * 900000);
  return `BS${n}`;
}

/** URL ảnh QR VietQR (img.vietqr.io) */
export function buildVietQRUrl(
  bankBin: string,
  account: string,
  accountName: string,
  amount: number,
  addInfo: string,
): string {
  const name = encodeURIComponent(unsignVietnamese(accountName));
  const info = encodeURIComponent(unsignVietnamese(addInfo));
  return `https://img.vietqr.io/image/${bankBin}-${account}-compact2.png?amount=${amount}&addInfo=${info}&accountName=${name}`;
}

export function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'vừa xong';
  if (m < 60) return `${m} phút trước`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} giờ trước`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d} ngày trước`;
  return new Date(ts).toLocaleDateString('vi-VN');
}

/** Chuẩn hóa SĐT Việt Nam: bỏ khoảng trắng, dấu chấm/gạch */
export function normalizePhone(p: string): string {
  let s = p.replace(/[\s.\-]/g, '');
  if (s.startsWith('+84')) s = '0' + s.slice(3);
  return s;
}

/** Kiểm tra SĐT Việt Nam hợp lệ (09/03/07/08/05 + 8 số) */
export function isValidVNPhone(p: string): boolean {
  return /^(0)(3|5|7|8|9)\d{8}$/.test(normalizePhone(p));
}

export function isValidEmail(e: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.trim());
}

/** Lấy tên ngân hàng từ mã BIN (bảng phổ biến, có thể thiếu) */
export function bankNameFromBin(bin: string): string {
  const map: Record<string, string> = {
    '970436': 'Vietcombank', '970415': 'VietinBank', '970407': 'Techcombank',
    '970418': 'BIDV', '970405': 'Agribank', '970403': 'Sacombank',
    '970416': 'ACB', '970422': 'MBBank', '970423': 'TPBank',
    '970424': 'Shinhan', '970441': 'VIB', '970432': 'VPBank',
    '970443': 'SHB', '970431': 'Eximbank', '970437': 'HDBank',
  };
  return map[bin] || '';
}
