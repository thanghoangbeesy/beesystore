// Kiểu dữ liệu dùng chung cho Beesy Store

// Một phiên bản bán riêng của sản phẩm (mỗi phiên bản có giá + file giao riêng)
export interface ProductVersion {
  name: string;          // tên phiên bản, VD: "v1.0" hoặc "v2.7 (bản mới nhất)"
  price: number;         // giá riêng của phiên bản này (đ)
  oldPrice?: number;     // giá gốc của phiên bản này (nếu đang giảm)
  note?: string;         // ghi chú ngắn, VD: "Đầy đủ tính năng + hỗ trợ 12 tháng"
  fileUrl: string;       // link file giao của phiên bản này
  fileName: string;      // tên file hiển thị của phiên bản này
}

export interface Product {
  id: string;
  name: string;          // VD: "Beesy Trọ"
  type: string;          // VD: "Google Sheet" | "Webapp" | "Website"
  version: string;       // phiên bản chính (mặc định = phiên bản đầu trong versions)
  price: number;         // giá thấp nhất trong các phiên bản (để hiển thị "Từ ...")
  oldPrice?: number;     // giá gốc (nếu đang giảm)
  versions?: ProductVersion[]; // danh sách phiên bản bán riêng; trống = chỉ 1 bản theo các trường trên
  tag?: string;          // nhãn nổi bật: "BÁN CHẠY", "MỚI", "MIỄN PHÍ"
  shortDesc: string;     // mô tả ngắn trên thẻ
  description: string;   // mô tả chi tiết (hỗ trợ đoạn văn)
  features: string[];    // danh sách tính năng nổi bật
  thumbnail: string;     // ảnh đại diện (URL)
  gallery: string[];     // ảnh minh họa thêm
  fileUrl: string;       // link file giao sau khi thanh toán (Drive/zip)
  fileName: string;      // tên file hiển thị, VD: "beesy-tro-v2.7.zip"
  active: boolean;       // true = đang bán
  featured: boolean;     // true = hiện ở mục nổi bật
  soldCount: number;     // số lượt bán (hiển thị)
  createdAt: number;
  updatedAt: number;
}

export type OrderStatus =
  | 'pending'    // chờ thanh toán
  | 'paid'       // đã thanh toán, chờ xác nhận
  | 'confirmed'  // admin đã xác nhận -> giao file
  | 'cancelled'; // đã hủy

export interface OrderItem {
  productId: string;
  productName: string;
  version: string;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  code: string;          // mã đơn: BSxxxxxx (duy nhất, tăng dần, không tái dùng)
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  note?: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;      // giảm từ voucher
  voucherCode?: string;
  total: number;
  status: OrderStatus;
  paymentMethod: 'bank'; // hiện tại chỉ chuyển khoản VietQR
  paidAt?: number;
  confirmedAt?: number;
  createdAt: number;
}

export interface Voucher {
  id: string;
  code: string;          // VD: "BEESY40"
  type: 'percent' | 'fixed';
  value: number;         // % hoặc số tiền
  maxDiscount?: number;  // trần giảm (cho loại %)
  minOrder?: number;     // đơn tối thiểu
  usageLimit?: number;   // số lượt dùng tối đa
  usedCount: number;
  active: boolean;
  expiresAt?: number;
}

export interface StoreSettings {
  shopName: string;      // "Beesy Store"
  hotline: string;       // "0943 571 886"
  zalo: string;          // số Zalo
  bankBin: string;       // mã BIN ngân hàng nhận tiền
  bankAccount: string;   // STK
  bankAccountName: string;
  bannerText: string;    // chữ trên banner khuyến mãi
  bannerActive: boolean;
  heroTitle: string;
  heroSubtitle: string;
  adminUids: string[];   // uid Firebase của chủ shop (quyền admin)
}

export interface AdminUser {
  uid: string;
  email: string;
  role: 'owner';
}
