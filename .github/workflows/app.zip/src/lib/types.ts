// Kiểu dữ liệu dùng chung cho Beesy Store

export interface Product {
  id: string;
  name: string;          // VD: "Beesy Trọ"
  type: string;          // VD: "Google Sheet" | "Webapp" | "Website"
  version: string;       // VD: "v2.7"
  price: number;         // giá bán (đ)
  oldPrice?: number;     // giá gốc (nếu đang giảm)
  tag?: string;          // nhãn nổi bật: "BÁN CHẠY", "MỚI", "MIỄN PHÍ"
  shortDesc: string;     // mô tả ngắn trên thẻ
  description: string;   // mô tả chi tiết (hỗ trợ đoạn văn)
  features: string[];    // danh sách tính năng nổi bật
  thumbnail: string;     // ảnh đại diện (URL)
  gallery: string[];     // ảnh minh họa thêm
  fileUrl: string;       // link file giao sau khi thanh toán (Drive/zip)
  fileName: string;      // tên file hiển thị, VD: "beesy-tro-v2.7.zip"
  active: boolean;       // true = đang bán
  featured: boolean;     // true = hiện ở mục nổi bật
  soldCount: number;     // số lượt bán (hiển thị)
  createdAt: number;
  updatedAt: number;
}

export type OrderStatus =
  | 'pending'    // chờ thanh toán
  | 'paid'       // đã thanh toán, chờ xác nhận
  | 'confirmed'  // admin đã xác nhận -> giao file
  | 'cancelled'; // đã hủy

export interface OrderItem {
  productId: string;
  productName: string;
  version: string;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  code: string;          // mã đơn: BSxxxxxx (duy nhất, tăng dần, không tái dùng)
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  note?: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;      // giảm từ voucher
  voucherCode?: string;
  total: number;
  status: OrderStatus;
  paymentMethod: 'bank'; // hiện tại chỉ chuyển khoản VietQR
  paidAt?: number;
  confirmedAt?: number;
  createdAt: number;
}

export interface Voucher {
  id: string;
  code: string;          // VD: "BEESY40"
  type: 'percent' | 'fixed';
  value: number;         // % hoặc số tiền
  maxDiscount?: number;  // trần giảm (cho loại %)
  minOrder?: number;     // đơn tối thiểu
  usageLimit?: number;   // số lượt dùng tối đa
  usedCount: number;
  active: boolean;
  expiresAt?: number;
}

export interface StoreSettings {
  shopName: string;      // "Beesy Store"
  hotline: string;       // "0943 571 886"
  zalo: string;          // số Zalo
  bankBin: string;       // mã BIN ngân hàng nhận tiền
  bankAccount: string;   // STK
  bankAccountName: string;
  bannerText: string;    // chữ trên banner khuyến mãi
  bannerActive: boolean;
  heroTitle: string;
  heroSubtitle: string;
  adminUids: string[];   // uid Firebase của chủ shop (quyền admin)
}

export interface AdminUser {
  uid: string;
  email: string;
  role: 'owner';
}
