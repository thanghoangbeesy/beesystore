// Seed dữ liệu mẫu cho Beesy Store: node scripts/seed.mjs
// Đọc config từ file .env ở thư mục gốc (6 biến VITE_FIREBASE_*).
// Nội dung 100% tự viết - không sao chép từ bất kỳ trang nào.
import { readFileSync, existsSync } from 'fs';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc } from 'firebase/firestore';

const envPath = new URL('../.env', import.meta.url);
if (!existsSync(envPath)) {
  console.error('[Loi] Chưa có file .env - copy từ .env.example rồi điền config Firebase.');
  process.exit(1);
}
const env = {};
for (const line of readFileSync(envPath, 'utf8').split('\n')) {
  const m = line.match(/^([A-Z_]+)=(.*)$/);
  if (m) env[m[1]] = m[2].trim();
}
for (const k of ['VITE_FIREBASE_API_KEY', 'VITE_FIREBASE_PROJECT_ID']) {
  if (!env[k]) {
    console.error(`[Loi] Thiếu ${k} trong .env`);
    process.exit(1);
  }
}

const app = initializeApp({
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.VITE_FIREBASE_APP_ID,
});
const db = getFirestore(app);
const now = Date.now();

const products = [
  {
    id: 'beesy-pos',
    name: 'Beesy POS',
    type: 'Webapp',
    version: 'v5.0',
    price: 1490000, // TODO: Hoàng chốt giá chính thức
    tag: 'BÁN CHẠY',
    shortDesc: 'Webapp bán hàng cho quán cafe, trà sữa: thu ngân tại quầy, quản lý menu, kho và báo cáo.',
    description:
      'Beesy POS là webapp bán hàng được xây dựng từ chính nhu cầu vận hành quán cafe mỗi ngày: chạm là bán, không rườm rà. Giao diện gọn, hiện đại, chạy mượt trên điện thoại, tablet và máy tính.\n\nBạn nhận được toàn bộ mã nguồn kèm hướng dẫn cài đặt từng bước trên điện thoại - không cần biết lập trình vẫn triển khai được. Mua một lần, dùng vĩnh viễn, không phí thuê bao hằng tháng.',
    features: [
      'Bán hàng tại quầy, in hóa đơn có mã QR thanh toán',
      'Quản lý menu, danh mục, giá bán theo size/topping',
      'Quản lý kho đa kho, phiếu nhập/xuất, cảnh báo hết hàng',
      'Báo cáo doanh thu, lợi nhuận theo ngày/tuần/tháng',
      'Quản lý khách hàng, công nợ, tích điểm đổi thưởng',
      'Sổ quỹ thu chi, phân quyền nhân viên theo ca',
      'Chạy tốt trên điện thoại, tablet và PC',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng
    fileName: 'beesy-pos-v5.zip',
    active: true,
    featured: true,
    soldCount: 12,
    createdAt: now,
    updatedAt: now,
  },
  {
    id: 'beesy-tro',
    name: 'Beesy Trọ',
    type: 'Google Sheet',
    version: 'v2.7',
    price: 469000,
    tag: 'BÁN CHẠY',
    shortDesc: 'Quản lý nhà trọ trên Google Sheet: phòng, khách thuê, điện nước, hóa đơn và sổ quỹ.',
    description:
      'Beesy Trọ giúp chủ trọ quản lý cả dãy phòng ngay trên Google Sheet quen thuộc - không cần cài app, không cần máy chủ. Mọi thứ chạy tự động: chốt chỉ số điện nước, lập hóa đơn có mã QR chuyển khoản, gửi hóa đơn qua Zalo cho khách thuê.\n\nMua một lần dùng trọn đời, được cập nhật các bản mới và hỗ trợ kỹ thuật 12 tháng.',
    features: [
      'Quản lý phòng, khách thuê, hợp đồng thuê',
      'Ghi chỉ số điện nước, tự tính tiền theo từng kỳ',
      'Xuất hóa đơn có mã QR chuyển khoản VietQR',
      'Gửi hóa đơn cho khách qua Zalo trong 1 chạm',
      'Sổ quỹ thu chi, quản lý tiền cọc, tài sản',
      'Báo cáo doanh thu theo tháng/năm, xuất Excel',
      'Chạy trên Google Sheet - không cần cài đặt gì thêm',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng
    fileName: 'beesy-tro-v2.zip',
    active: true,
    featured: true,
    soldCount: 30,
    createdAt: now,
    updatedAt: now,
  },
  {
    id: 'littlebees',
    name: 'LittleBees',
    type: 'Website',
    version: 'v3.0',
    price: 990000, // TODO: Hoàng chốt giá chính thức
    tag: 'MỚI',
    shortDesc: 'Website cho lớp tiền tiểu học: bài học, game tương tác, album ảnh và quản lý học sinh.',
    description:
      'LittleBees là website dành cho lớp tiền tiểu học với giao diện tươi sáng, thân thiện với trẻ. Cô giáo đăng bài học, tổ chức game tương tác ngay trên lớp; phụ huynh theo dõi tiến trình, điểm danh và học phí của con qua tài khoản riêng.\n\nBạn nhận toàn bộ mã nguồn kèm hướng dẫn triển khai chi tiết. Mua một lần, dùng vĩnh viễn.',
    features: [
      'Trang lớp học với bài học theo 4 dạng: đọc, xem, nghe, viết',
      '4 game tương tác cho bé chơi trực tiếp trên lớp',
      'Album ảnh, video hoạt động của lớp',
      'Tài khoản phụ huynh: xem điểm danh, tiến trình, học phí',
      'Quản lý học sinh, học phí theo lớp/kỳ',
      'Bảng tin, form đăng ký học thử, vinh danh bé ngoan',
    ],
    thumbnail: '',
    gallery: [],
    fileUrl: '', // TODO: Hoàng dán link file giao hàng
    fileName: 'littlebees-v3.zip',
    active: true,
    featured: true,
    soldCount: 5,
    createdAt: now,
    updatedAt: now,
  },
];

const settings = {
  shopName: 'Beesy Store',
  hotline: '0943 571 886',
  zalo: '0943 571 886',
  bankBin: '', // TODO: Hoàng điền mã BIN ngân hàng nhận tiền
  bankAccount: '', // TODO: Hoàng điền STK
  bankAccountName: '', // TODO: Hoàng điền chủ tài khoản
  bannerText: 'Khai trương Beesy Store - Ưu đãi đến 40% cho các gói trả phí',
  bannerActive: true,
  heroTitle: 'Kho webapp & template cho công việc của bạn',
  heroSubtitle: 'Mua một lần, dùng vĩnh viễn. Thanh toán chuyển khoản nhanh gọn - nhận file ngay sau khi shop xác nhận.',
  adminUids: [], // TODO: Hoàng thêm UID tài khoản admin sau khi tạo user
};

const vouchers = [
  {
    id: 'v-mau',
    code: 'MẪU-10',
    type: 'percent',
    value: 10,
    maxDiscount: 100000,
    usedCount: 0,
    active: false, // voucher mẫu (đang tắt) để admin tham khảo cách tạo
  },
];

async function main() {
  for (const p of products) {
    await setDoc(doc(db, 'products', p.id), p, { merge: true });
    console.log('[OK] product', p.id);
  }
  await setDoc(doc(db, 'settings', 'store'), settings, { merge: true });
  console.log('[OK] settings/store');
  for (const v of vouchers) {
    await setDoc(doc(db, 'vouchers', v.id), v, { merge: true });
    console.log('[OK] voucher', v.code);
  }
  await setDoc(doc(db, 'counters', 'orders'), { seq: 100000 }, { merge: true });
  console.log('[OK] counters/orders');
  console.log('\nXong! Nhớ tạo tài khoản admin (Authentication -> Users) rồi thêm UID vào settings/store.adminUids.');
}

main().catch((e) => {
  console.error('[Loi] Seed lỗi:', e.message);
  process.exit(1);
});
